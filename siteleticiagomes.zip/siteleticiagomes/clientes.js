
(() => {
    "use strict";

    const CLIENTS_KEY = "leticia_clients_v1";
    const REQUESTS_KEY = "leticia_dashboard_v1";

    const $ = id => document.getElementById(id);
    const today = () => new Date().toISOString().slice(0, 10);

    let clients = loadClients();
    let activeClientId = null;

    function makeId() {
        return "cli_" + Date.now().toString(36) +
            Math.random().toString(36).slice(2, 7);
    }

    function numberOrZero(value) {
        const number = Number(value);
        return Number.isFinite(number) && number >= 0 ? number : 0;
    }

    function normalizeClient(client) {
        return {
            id: String(client.id || makeId()),
            name: String(client.name || ""),
            email: String(client.email || ""),
            phone: String(client.phone || ""),
            relationship: client.relationship || "Lead",
            lastSession: client.lastSession || "",
            lastSessionType: client.lastSessionType || "",
            paymentStatus: client.paymentStatus || "Não se aplica",
            paymentAmount: numberOrZero(client.paymentAmount),
            paidAmount: numberOrZero(client.paidAmount),
            proposalStatus: client.proposalStatus || "Não elaborada",
            proposalAmount: numberOrZero(client.proposalAmount),
            notes: String(client.notes || ""),
            history: Array.isArray(client.history) ? client.history : [],
            createdAt: client.createdAt || today(),
            updatedAt: client.updatedAt || today(),
            sourceRequestId: String(client.sourceRequestId || "")
        };
    }

    function loadClients() {
        try {
            const stored = JSON.parse(localStorage.getItem(CLIENTS_KEY) || "[]");
            return Array.isArray(stored) ? stored.map(normalizeClient) : [];
        } catch {
            return [];
        }
    }

    function saveClients() {
        localStorage.setItem(CLIENTS_KEY, JSON.stringify(clients));
    }

    function readRequests() {
        try {
            const data = JSON.parse(localStorage.getItem(REQUESTS_KEY) || "{}");
            return Array.isArray(data.requests) ? data.requests : [];
        } catch {
            return [];
        }
    }

    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g, character => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        })[character]);
    }

    function formatDate(value) {
        if (!value) return "—";

        const date = new Date(value + "T12:00:00");

        return Number.isNaN(date.getTime())
            ? "—"
            : date.toLocaleDateString("pt-BR");
    }

    function currency(value) {
        return Number(value || 0).toLocaleString("pt-BR", {
            style: "currency",
            currency: "BRL"
        });
    }

    function initials(name) {
        return String(name || "?")
            .trim()
            .split(/\s+/)
            .slice(0, 2)
            .map(part => part[0] || "")
            .join("")
            .toUpperCase();
    }

    function relationshipLabel(value) {
        return ({
            Lead: "Em contato",
            Cliente: "Cliente",
            Recorrente: "Recorrente",
            Inativo: "Sem atividade"
        })[value] || value;
    }

    function relationshipClass(value) {
        return ({
            Lead: "lead",
            Cliente: "cliente",
            Recorrente: "recorrente",
            Inativo: "inativo"
        })[value] || "";
    }

    function paymentClass(value) {
        if (value === "Pago") return "pago";
        if (value === "Pendente") return "pendente";
        return "";
    }

    function lastUpdate(client) {
        const historyDates = client.history
            .map(item => item.date)
            .filter(Boolean)
            .sort();

        return historyDates.at(-1) || client.updatedAt || "";
    }

    // TABELA E FILTROS

    function render() {
        const search = $("searchInput").value
            .trim()
            .toLocaleLowerCase("pt-BR");

        const relationship = $("relationshipFilter").value;
        const session = $("sessionFilter").value;
        const payment = $("paymentFilter").value;

        const filtered = clients.filter(client => {
            const searchable = [
                client.name,
                client.email,
                client.phone,
                client.lastSessionType,
                client.notes
            ].join(" ").toLocaleLowerCase("pt-BR");

            const matchesSearch = searchable.includes(search);
            const matchesRelationship =
                !relationship || client.relationship === relationship;

            const hasSession = Boolean(
                client.lastSession || client.lastSessionType
            );

            const matchesSession =
                !session ||
                (session === "com" && hasSession) ||
                (session === "sem" && !hasSession);

            const matchesPayment =
                !payment || client.paymentStatus === payment;

            return matchesSearch &&
                matchesRelationship &&
                matchesSession &&
                matchesPayment;
        }).sort((a, b) => a.name.localeCompare(b.name, "pt-BR"));

        $("totalClients").textContent = clients.length;

        $("clientsWithSessions").textContent = clients.filter(client =>
            client.lastSession || client.lastSessionType
        ).length;

        $("openProposals").textContent = clients.filter(client =>
            ["Rascunho", "Enviada"].includes(client.proposalStatus)
        ).length;

        $("pendingPayments").textContent = clients.filter(client =>
            ["Pendente", "Parcial"].includes(client.paymentStatus)
        ).length;

        $("resultCount").textContent =
            `${filtered.length} ${filtered.length === 1 ? "cliente" : "clientes"}`;

        $("clientsTableBody").innerHTML = filtered.map(client => `
            <tr>
                <td>
                    <div class="client-cell">
                        <span class="avatar">${escapeHTML(initials(client.name))}</span>
                        <div>
                            <span class="client-name">${escapeHTML(client.name)}</span>
                            <span class="client-sub">
                                ${escapeHTML(client.lastSessionType || "Sem ensaio registrado")}
                            </span>
                        </div>
                    </div>
                </td>

                <td class="contact-cell">
                    ${client.email ? `<div>${escapeHTML(client.email)}</div>` : ""}
                    ${client.phone ? `<div>${escapeHTML(client.phone)}</div>` : ""}
                    ${!client.email && !client.phone
                        ? '<span class="muted">Sem contato</span>' : ""}
                </td>

                <td>${escapeHTML(formatDate(client.lastSession))}</td>

                <td>
                    <span class="pill ${relationshipClass(client.relationship)}">
                        ${escapeHTML(relationshipLabel(client.relationship))}
                    </span>
                </td>

                <td>
                    <span class="pill ${paymentClass(client.paymentStatus)}">
                        ${escapeHTML(client.paymentStatus)}
                    </span>
                </td>

                <td>${escapeHTML(formatDate(lastUpdate(client)))}</td>

                <td>
                    <button class="row-action" type="button"
                        data-profile="${escapeHTML(client.id)}">
                        Abrir ficha
                    </button>
                </td>
            </tr>
        `).join("");

        $("emptyState").hidden = filtered.length !== 0;

        $("clientsTableBody").closest("table").style.display =
            filtered.length ? "" : "none";
    }

    // CADASTRO E EDIÇÃO

    function openClientModal(client = null) {
        $("clientForm").reset();
        $("formError").textContent = "";

        $("clientId").value = client?.id || "";
        $("modalTitle").textContent = client ? "Editar cliente" : "Novo cliente";

        $("clientName").value = client?.name || "";
        $("clientEmail").value = client?.email || "";
        $("clientPhone").value = client?.phone || "";
        $("clientRelationship").value = client?.relationship || "Lead";
        $("lastSession").value = client?.lastSession || "";
        $("lastSessionType").value = client?.lastSessionType || "";
        $("paymentStatus").value = client?.paymentStatus || "Não se aplica";
        $("paymentAmount").value = client?.paymentAmount || "";
        $("paidAmount").value = client?.paidAmount || "";
        $("proposalStatus").value = client?.proposalStatus || "Não elaborada";
        $("proposalAmount").value = client?.proposalAmount || "";
        $("clientNotes").value = client?.notes || "";

        $("clientModal").hidden = false;
        $("clientName").focus();
    }

    function closeClientModal() {
        $("clientModal").hidden = true;
    }

    $("newClientButton").addEventListener("click", () => openClientModal());
    $("emptyNewClient").addEventListener("click", () => openClientModal());
    $("closeModal").addEventListener("click", closeClientModal);
    $("cancelModal").addEventListener("click", closeClientModal);

    $("clientModal").addEventListener("click", event => {
        if (event.target === $("clientModal")) closeClientModal();
    });

    $("clientForm").addEventListener("submit", event => {
        event.preventDefault();

        const id = $("clientId").value;
        const existing = clients.find(client => client.id === id);

        const amount = Number($("paymentAmount").value || 0);
        const paid = Number($("paidAmount").value || 0);
        const proposalAmount = Number($("proposalAmount").value || 0);

        if (paid > amount) {
            $("formError").textContent =
                "O total pago não pode ser maior que o valor combinado.";
            return;
        }

        if (!Number.isFinite(amount) || amount < 0 ||
            !Number.isFinite(paid) || paid < 0 ||
            !Number.isFinite(proposalAmount) || proposalAmount < 0) {
            $("formError").textContent = "Confira os valores informados.";
            return;
        }

        const client = normalizeClient({
            ...(existing || {}),
            id: id || makeId(),
            name: $("clientName").value.trim(),
            email: $("clientEmail").value.trim(),
            phone: $("clientPhone").value.trim(),
            relationship: $("clientRelationship").value,
            lastSession: $("lastSession").value,
            lastSessionType: $("lastSessionType").value.trim(),
            paymentStatus: $("paymentStatus").value,
            paymentAmount: amount,
            paidAmount: paid,
            proposalStatus: $("proposalStatus").value,
            proposalAmount,
            notes: $("clientNotes").value.trim(),
            createdAt: existing?.createdAt || today(),
            updatedAt: today(),
            history: existing?.history || []
        });

        if (!client.name) {
            $("formError").textContent = "Informe o nome do cliente.";
            return;
        }

        if (id) {
            clients = clients.map(item => item.id === id ? client : item);
        } else {
            client.history.push({
                date: today(),
                type: "Observação",
                text: "Cadastro criado manualmente."
            });
            clients.push(client);
        }

        saveClients();
        closeClientModal();
        render();

        if (activeClientId === client.id) {
            openProfile(client.id);
        }
    });

    // FICHA DO CLIENTE

    function openProfile(id) {
        const client = clients.find(item => item.id === id);
        if (!client) return;

        activeClientId = id;

        $("profileName").textContent = client.name;
        $("profileContact").textContent =
            [client.email, client.phone].filter(Boolean).join(" · ") ||
            "Sem contato cadastrado";

        $("profileDetails").innerHTML = [
            ["Relacionamento", relationshipLabel(client.relationship)],
            ["E-mail", client.email || "Não informado"],
            ["Telefone", client.phone || "Não informado"],
            ["Último ensaio", formatDate(client.lastSession)],
            ["Tipo de ensaio", client.lastSessionType || "Não informado"],
            ["Observações", client.notes || "Nenhuma observação cadastrada"]
        ].map(([label, value]) => `
            <div>
                <dt>${escapeHTML(label)}</dt>
                <dd>${escapeHTML(value)}</dd>
            </div>
        `).join("");

        const balance = Math.max(
            0,
            client.paymentAmount - client.paidAmount
        );

        $("profileBusinessDetails").innerHTML = `
            <div class="business-item">
                <span>Valor combinado</span>
                <strong>${currency(client.paymentAmount)}</strong>
            </div>

            <div class="business-item">
                <span>Total pago</span>
                <strong>${currency(client.paidAmount)}</strong>
            </div>

            <div class="business-item">
                <span>Saldo restante</span>
                <strong>${currency(balance)}</strong>
            </div>

            <div class="business-item">
                <span>Situação do pagamento</span>
                <strong>${escapeHTML(client.paymentStatus)}</strong>
            </div>

            <div class="business-item">
                <span>Proposta</span>
                <strong>${escapeHTML(client.proposalStatus)}</strong>
                <p>Valor: ${currency(client.proposalAmount)}</p>
            </div>

            <div class="business-item">
                <span>Data do cadastro</span>
                <strong>${escapeHTML(formatDate(client.createdAt))}</strong>
            </div>
        `;

        renderHistory(client);

        $("historyForm").hidden = true;
        $("profileModal").hidden = false;
    }

    function renderHistory(client) {
        const history = [...client.history].sort((a, b) =>
            String(b.date).localeCompare(String(a.date))
        );

        $("historyTimeline").innerHTML = history.length
            ? history.map(item => `
                <article class="timeline-item">
                    <div class="timeline-date">${escapeHTML(formatDate(item.date))}</div>
                    <div>
                        <div class="timeline-type">${escapeHTML(item.type)}</div>
                        <p class="timeline-text">${escapeHTML(item.text)}</p>
                    </div>
                </article>
            `).join("")
            : '<p class="timeline-empty">Nenhum registro ainda. Adicione uma conversa, proposta, ensaio ou pagamento.</p>';
    }

    function closeProfile() {
        $("profileModal").hidden = true;
        activeClientId = null;
    }

    $("clientsTableBody").addEventListener("click", event => {
        const button = event.target.closest("[data-profile]");
        if (button) openProfile(button.dataset.profile);
    });

    $("closeProfile").addEventListener("click", closeProfile);

    $("profileModal").addEventListener("click", event => {
        if (event.target === $("profileModal")) closeProfile();
    });

    $("editFromProfile").addEventListener("click", () => {
        const client = clients.find(item => item.id === activeClientId);
        if (!client) return;

        $("profileModal").hidden = true;
        openClientModal(client);
    });

    // HISTÓRICO

    $("addHistoryButton").addEventListener("click", () => {
        $("historyForm").hidden = false;
        $("historyDate").value = today();
        $("historyText").value = "";
        $("historyText").focus();
    });

    $("cancelHistory").addEventListener("click", () => {
        $("historyForm").hidden = true;
    });

    $("historyForm").addEventListener("submit", event => {
        event.preventDefault();

        const client = clients.find(item => item.id === activeClientId);
        if (!client) return;

        const text = $("historyText").value.trim();
        if (!text) return;

        const date = $("historyDate").value || today();
        const type = $("historyType").value;

        client.history.push({ date, type, text });
        client.updatedAt = today();

        // Atualiza também o campo principal quando o registro é um ensaio.
        if (type === "Ensaio") {
            client.lastSession = date;
            client.lastSessionType = text;
        }

        if (type === "Pagamento") {
            client.paymentStatus =
                client.paidAmount >= client.paymentAmount
                    ? "Pago"
                    : client.paidAmount > 0
                        ? "Parcial"
                        : "Pendente";
        }

        saveClients();
        render();
        openProfile(client.id);
    });

    // FILTROS

    ["searchInput", "relationshipFilter", "sessionFilter", "paymentFilter"]
        .forEach(id => {
            const eventName = id === "searchInput" ? "input" : "change";
            $(id).addEventListener(eventName, render);
        });

    $("clearFilters").addEventListener("click", () => {
        $("searchInput").value = "";
        $("relationshipFilter").value = "";
        $("sessionFilter").value = "";
        $("paymentFilter").value = "";
        render();
    });

    // EXPORTAÇÃO CSV — ABRE NO EXCEL

    $("exportButton").addEventListener("click", () => {
        const headers = [
            "Nome", "E-mail", "Telefone", "Relacionamento",
            "Último ensaio", "Tipo de ensaio", "Pagamento",
            "Valor combinado", "Total pago", "Saldo",
            "Status da proposta", "Valor da proposta",
            "Observações", "Histórico"
        ];

        const rows = clients.map(client => [
            client.name,
            client.email,
            client.phone,
            relationshipLabel(client.relationship),
            formatDate(client.lastSession),
            client.lastSessionType,
            client.paymentStatus,
            client.paymentAmount.toFixed(2).replace(".", ","),
            client.paidAmount.toFixed(2).replace(".", ","),
            Math.max(0, client.paymentAmount - client.paidAmount)
                .toFixed(2).replace(".", ","),
            client.proposalStatus,
            client.proposalAmount.toFixed(2).replace(".", ","),
            client.notes,
            client.history.map(item =>
                `${formatDate(item.date)} [${item.type}] ${item.text}`
            ).join(" | ")
        ]);

        const cell = value =>
            `"${String(value ?? "").replace(/"/g, '""')}"`;

        const csv = "\uFEFF" +
            [headers, ...rows]
                .map(row => row.map(cell).join(";"))
                .join("\r\n");

        const blob = new Blob([csv], {
            type: "text/csv;charset=utf-8;"
        });

        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");

        link.href = url;
        link.download = `clientes-leticia-${today()}.csv`;

        document.body.appendChild(link);
        link.click();
        link.remove();

        URL.revokeObjectURL(url);
    });

    // IMPORTAR CLIENTES DAS SOLICITAÇÕES

    function openRequestsModal() {
        const requests = readRequests().filter(request =>
            !clients.some(client =>
                client.sourceRequestId &&
                client.sourceRequestId === String(request.id)
            )
        );

        if (!requests.length) {
            $("requestChoices").innerHTML =
                '<p class="timeline-empty">Nenhuma solicitação disponível para importar. Confira se há registros na aba Solicitações.</p>';
        } else {
            $("requestChoices").innerHTML = requests.map(request => `
                <div class="request-choice">
                    <div>
                        <strong>${escapeHTML(request.name || "Sem nome")}</strong>
                        <span>
                            ${escapeHTML(request.email || "Sem e-mail")}
                            · ${escapeHTML(request.phone || "Sem telefone")}
                        </span>
                        <span>
                            ${escapeHTML(request.service || "Ensaio não informado")}
                            · Data desejada: ${escapeHTML(formatDate(request.date))}
                        </span>
                    </div>

                    <button class="button button-outline" type="button"
                        data-import="${escapeHTML(request.id)}">
                        Cadastrar
                    </button>
                </div>
            `).join("");
        }

        $("requestModal").hidden = false;
    }

    function importRequest(id) {
        const request = readRequests().find(item =>
            String(item.id) === String(id)
        );

        if (!request) return;

        const client = normalizeClient({
            id: makeId(),
            name: request.name || "",
            email: request.email || "",
            phone: request.phone || "",
            relationship: request.status === "Confirmada" ? "Cliente" : "Lead",
            lastSession: "",
            lastSessionType: request.service || "",
            paymentStatus: "Não se aplica",
            paymentAmount: 0,
            paidAmount: 0,
            proposalStatus: request.proposalStatus || "Não elaborada",
            proposalAmount: request.proposalAmount || 0,
            notes: request.notes || "",
            sourceRequestId: String(request.id),
            createdAt: today(),
            updatedAt: today(),
            history: [{
                date: today(),
                type: "Contato",
                text: "Cadastro criado a partir de uma solicitação. " +
                    "Status da solicitação: " + (request.status || "não informado") + "."
            }]
        });

        clients.push(client);
        saveClients();

        $("requestModal").hidden = true;

        render();
        openProfile(client.id);
    }

    $("importRequestButton").addEventListener("click", openRequestsModal);

    $("requestChoices").addEventListener("click", event => {
        const button = event.target.closest("[data-import]");
        if (button) importRequest(button.dataset.import);
    });

    $("closeRequestModal").addEventListener("click", () => {
        $("requestModal").hidden = true;
    });

    $("cancelRequestModal").addEventListener("click", () => {
        $("requestModal").hidden = true;
    });

    $("requestModal").addEventListener("click", event => {
        if (event.target === $("requestModal")) {
            $("requestModal").hidden = true;
        }
    });

    // MENU PARA CELULAR E SAÍDA

    $("logoutButton").addEventListener("click", () => {
        window.location.href = "login.html";
    });

    $("menuButton").addEventListener("click", () => {
        $("sidebar").classList.toggle("open");
        $("overlay").classList.toggle("show");
    });

    $("overlay").addEventListener("click", () => {
        $("sidebar").classList.remove("open");
        $("overlay").classList.remove("show");
    });

    document.addEventListener("keydown", event => {
        if (event.key === "Escape") {
            closeClientModal();
            closeProfile();
            $("requestModal").hidden = true;
            $("sidebar").classList.remove("open");
            $("overlay").classList.remove("show");
        }
    });

    render();
})();
