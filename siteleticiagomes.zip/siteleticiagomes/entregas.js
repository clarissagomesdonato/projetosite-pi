
const STORAGE_KEY = "leticia_deliveries_v1";
const CLIENTS_KEY = "leticia_clients_v1";

const STATUSES = [
  "Produção",
  "Edição",
  "Revisão",
  "Pronta para entrega",
  "Entregue"
];

const $ = (id) => document.getElementById(id);

let deliveries = loadDeliveries();
let clients = loadClients();
let activeDetailId = null;

function loadDeliveries() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}

function loadClients() {
  try {
    const saved = JSON.parse(localStorage.getItem(CLIENTS_KEY) || "[]");
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}

function saveDeliveries() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(deliveries));
    return true;
  } catch {
    alert("Não foi possível salvar. Verifique o espaço disponível no navegador.");
    return false;
  }
}

function createId() {
  return window.crypto?.randomUUID?.()
    || `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[char]);
}

function normalizeText(value) {
  return String(value || "").trim();
}

function getClientName(clientId) {
  const client = clients.find((item) => String(item.id) === String(clientId));
  return client?.name || "";
}

function todayString() {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatDate(value) {
  if (!value) return "Não definido";

  const parts = value.split("-");
  if (parts.length !== 3) return value;

  return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

function getDaysUntil(dateString) {
  if (!dateString) return null;

  const today = new Date(`${todayString()}T00:00:00`);
  const target = new Date(`${dateString}T00:00:00`);

  if (Number.isNaN(target.getTime())) return null;

  return Math.round((target - today) / 86400000);
}

function isDelivered(item) {
  return item.status === "Entregue";
}

function isOverdue(item) {
  const days = getDaysUntil(item.deadline);
  return days !== null && days < 0 && !isDelivered(item);
}

function isUpcoming(item) {
  const days = getDaysUntil(item.deadline);
  return days !== null && days >= 0 && days <= 7 && !isDelivered(item);
}

function getStatusClass(status) {
  const classes = {
    "Produção": "status-production",
    "Edição": "status-editing",
    "Revisão": "status-review",
    "Pronta para entrega": "status-ready",
    "Entregue": "status-delivered"
  };

  return classes[status] || "status-production";
}

function renderStatus(status) {
  return `<span class="status-pill ${getStatusClass(status)}">${escapeHTML(status)}</span>`;
}

function renderClientOptions(selectedId = "") {
  const select = $("deliveryClient");

  select.innerHTML = `
    <option value="">Sem cliente associado</option>
    ${clients
      .slice()
      .sort((a, b) => String(a.name || "").localeCompare(String(b.name || ""), "pt-BR"))
      .map((client) => `
        <option value="${escapeHTML(client.id)}"
          ${String(client.id) === String(selectedId) ? "selected" : ""}>
          ${escapeHTML(client.name || "Cliente sem nome")}
        </option>
      `)
      .join("")}
  `;
}

function renderSummary() {
  const active = deliveries.filter((item) => !isDelivered(item));

  $("totalCount").textContent = deliveries.length;
  $("productionCount").textContent = active.filter((item) =>
    ["Produção", "Edição", "Revisão"].includes(item.status)
  ).length;
  $("deadlineCount").textContent = active.filter(isUpcoming).length;
  $("deliveredCount").textContent = deliveries.filter(isDelivered).length;
}

function renderDeliveryRow(item) {
  const clientName = getClientName(item.clientId);
  const days = getDaysUntil(item.deadline);

  let deadlineMessage = "";

  if (isDelivered(item)) {
    deadlineMessage = "Trabalho entregue";
  } else if (days === null) {
    deadlineMessage = "Defina um prazo";
  } else if (days < 0) {
    deadlineMessage = `Atrasado há ${Math.abs(days)} dia(s)`;
  } else if (days === 0) {
    deadlineMessage = "Prazo hoje";
  } else if (days <= 7) {
    deadlineMessage = `Faltam ${days} dia(s)`;
  }

  let deliveryStatus = "Ainda não enviada";

  if (item.confirmed) {
    deliveryStatus = "Conclusão confirmada";
  } else if (item.sentDate) {
    deliveryStatus = "Link enviado";
  } else if (item.link) {
    deliveryStatus = "Link cadastrado";
  }

  return `
    <tr>
      <td>
        <span class="delivery-name">${escapeHTML(item.title)}</span>
        <span class="delivery-meta">
          ${escapeHTML(item.type || "Ensaio não especificado")}
          ${clientName ? ` · ${escapeHTML(clientName)}` : ""}
        </span>
      </td>

      <td>
        <span class="deadline-date">${formatDate(item.deadline)}</span>
        <span class="deadline-warning"
          ${!isOverdue(item) && days !== 0 ? 'style="color:var(--texto-suave)"' : ""}>
          ${escapeHTML(deadlineMessage)}
        </span>
      </td>

      <td>${renderStatus(item.status)}</td>

      <td>
        <div class="delivery-state">
          <strong>${escapeHTML(deliveryStatus)}</strong>
          <small>${item.sentDate ? `Enviada em ${formatDate(item.sentDate)}` : "Sem data de envio"}</small>
        </div>
      </td>

      <td>
        <div class="row-actions">
          <button class="table-action" type="button"
            data-action="details" data-id="${escapeHTML(item.id)}">
            Ver
          </button>
          <button class="table-action" type="button"
            data-action="edit" data-id="${escapeHTML(item.id)}">
            Editar
          </button>
        </div>
      </td>
    </tr>
  `;
}

function renderDeliveries() {
  const search = normalizeText($("searchDelivery").value).toLocaleLowerCase("pt-BR");
  const status = $("statusFilter").value;
  const deadlineFilter = $("deadlineFilter").value;

  const filtered = deliveries.filter((item) => {
    const clientName = getClientName(item.clientId);

    const searchText = [
      item.title,
      item.type,
      item.notes,
      clientName
    ].join(" ").toLocaleLowerCase("pt-BR");

    if (search && !searchText.includes(search)) return false;
    if (status && item.status !== status) return false;

    if (deadlineFilter === "upcoming" && !isUpcoming(item)) return false;
    if (deadlineFilter === "overdue" && !isOverdue(item)) return false;
    if (deadlineFilter === "no-date" && item.deadline) return false;

    return true;
  });

  filtered.sort((a, b) => {
    if (!a.deadline && !b.deadline) return 0;
    if (!a.deadline) return 1;
    if (!b.deadline) return -1;
    return a.deadline.localeCompare(b.deadline);
  });

  $("deliveriesTableBody").innerHTML = filtered
    .map(renderDeliveryRow)
    .join("");

  $("resultCount").textContent =
    `${filtered.length} ${filtered.length === 1 ? "trabalho" : "trabalhos"}`;

  $("emptyState").classList.toggle("visible", filtered.length === 0);
  $("deliveriesTableBody").parentElement.style.display =
    filtered.length === 0 ? "none" : "table";

  const noRecords = deliveries.length === 0;
  $("emptyState").querySelector("h3").textContent = noRecords
    ? "Nenhum trabalho por aqui ainda"
    : "Nenhum resultado encontrado";

  $("emptyState").querySelector("p").textContent = noRecords
    ? "Cadastre um ensaio para começar a acompanhar a produção e a entrega."
    : "Tente alterar a busca ou os filtros para encontrar um trabalho.";

  $("emptyNewBtn").style.display = noRecords ? "inline-flex" : "none";
}

function renderAll() {
  renderSummary();
  renderDeliveries();
}

function openModal(id) {
  $(id).classList.add("open");
  $(id).setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
}

function closeModal(id) {
  $(id).classList.remove("open");
  $(id).setAttribute("aria-hidden", "true");

  if (!document.querySelector(".modal-backdrop.open")) {
    document.body.style.overflow = "";
  }
}

function openNewDelivery() {
  $("deliveryForm").reset();
  $("deliveryId").value = "";
  $("modalTitle").textContent = "Novo trabalho";
  $("formFeedback").textContent = "";
  $("deliveryStatus").value = "Produção";
  renderClientOptions();

  openModal("deliveryModal");
  $("deliveryTitle").focus();
}

function openEditDelivery(id) {
  const item = deliveries.find((delivery) => String(delivery.id) === String(id));
  if (!item) return;

  $("deliveryForm").reset();
  $("deliveryId").value = item.id;
  $("modalTitle").textContent = "Editar trabalho";
  $("formFeedback").textContent = "";

  $("deliveryTitle").value = item.title || "";
  $("deliveryType").value = item.type || "";
  $("deliveryDate").value = item.sessionDate || "";
  $("deliveryDeadline").value = item.deadline || "";
  $("deliveryStatus").value = item.status || "Produção";
  $("deliverySentDate").value = item.sentDate || "";
  $("deliveryLink").value = item.link || "";
  $("deliveryFiles").value = Array.isArray(item.files)
    ? item.files.join("\n")
    : "";
  $("deliveryNotes").value = item.notes || "";
  $("deliveryConfirmed").checked = Boolean(item.confirmed);

  renderClientOptions(item.clientId || "");
  closeModal("detailModal");
  openModal("deliveryModal");
}

function validUrl(value) {
  if (!value) return true;

  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:";
  } catch {
    return false;
  }
}

function handleSaveDelivery(event) {
  event.preventDefault();

  const id = $("deliveryId").value;
  const existing = deliveries.find((item) => String(item.id) === String(id));

  const title = normalizeText($("deliveryTitle").value);
  const status = $("deliveryStatus").value;
  const deadline = $("deliveryDeadline").value;
  const sentDate = $("deliverySentDate").value;
  const link = normalizeText($("deliveryLink").value);
  const confirmed = $("deliveryConfirmed").checked;

  $("formFeedback").textContent = "";

  if (!title) {
    $("formFeedback").textContent = "Informe o nome do trabalho.";
    return;
  }

  if (!STATUSES.includes(status)) {
    $("formFeedback").textContent = "Selecione um status válido.";
    return;
  }

  if (link && !validUrl(link)) {
    $("formFeedback").textContent = "Informe um link de entrega válido, começando com http:// ou https://.";
    return;
  }

  const files = $("deliveryFiles").value
    .split(/\r?\n/)
    .map((value) => value.trim())
    .filter(Boolean);

  const invalidFile = files.find((file) => !validUrl(file));

  if (invalidFile) {
    $("formFeedback").textContent =
      "Confira os links dos arquivos: use um link http:// ou https:// por linha.";
    return;
  }

  if (confirmed && status !== "Entregue") {
    $("formFeedback").textContent =
      'Para confirmar a conclusão, altere o status para "Entregue".';
    return;
  }

  if (status === "Entregue" && !sentDate) {
    $("formFeedback").textContent =
      "Informe a data de envio antes de marcar o trabalho como entregue.";
    return;
  }

  if (confirmed && !sentDate) {
    $("formFeedback").textContent =
      "Informe a data de envio antes de confirmar a conclusão.";
    return;
  }

  const now = new Date().toISOString();

  const item = {
    id: existing?.id || createId(),
    title,
    clientId: $("deliveryClient").value,
    type: normalizeText($("deliveryType").value),
    sessionDate: $("deliveryDate").value,
    deadline,
    status,
    sentDate,
    link,
    files,
    notes: normalizeText($("deliveryNotes").value),
    confirmed,
    confirmedAt: confirmed
      ? (existing?.confirmedAt || now)
      : "",
    createdAt: existing?.createdAt || now,
    updatedAt: now
  };

  const previousDeliveries = [...deliveries];

  if (existing) {
    deliveries = deliveries.map((delivery) =>
      String(delivery.id) === String(existing.id) ? item : delivery
    );
  } else {
    deliveries.push(item);
  }

  if (!saveDeliveries()) {
    deliveries = previousDeliveries;
    return;
  }

  closeModal("deliveryModal");
  renderAll();
}

function createLink(url, label) {
  if (!url || !validUrl(url)) {
    return `<span>Não informado</span>`;
  }

  return `<a href="${escapeHTML(url)}" target="_blank" rel="noopener noreferrer">${escapeHTML(label || url)}</a>`;
}

function showDetails(id) {
  const item = deliveries.find((delivery) => String(delivery.id) === String(id));
  if (!item) return;

  activeDetailId = item.id;

  const clientName = getClientName(item.clientId);
  const files = Array.isArray(item.files) ? item.files : [];

  const fileLinks = files.length
    ? files.map((url, index) =>
        `<div>${createLink(url, `Arquivo associado ${index + 1}`)}</div>`
      ).join("")
    : "<span>Nenhum arquivo associado.</span>";

  const deliveryConfirmation = item.confirmed
    ? `Confirmada${item.confirmedAt ? ` em ${new Date(item.confirmedAt).toLocaleDateString("pt-BR")}` : ""}`
    : "Pendente";

  $("detailTitle").textContent = item.title;

  $("detailBody").innerHTML = `
    <div class="detail-list">
      <div class="detail-item">
        <span>Cliente</span>
        <strong>${escapeHTML(clientName || "Não associado")}</strong>
      </div>

      <div class="detail-item">
        <span>Tipo de ensaio</span>
        <strong>${escapeHTML(item.type || "Não especificado")}</strong>
      </div>

      <div class="detail-item">
        <span>Data do ensaio</span>
        <strong>${formatDate(item.sessionDate)}</strong>
      </div>

      <div class="detail-item">
        <span>Prazo de entrega</span>
        <strong>${formatDate(item.deadline)}</strong>
      </div>

      <div class="detail-item">
        <span>Status atual</span>
        <strong>${escapeHTML(item.status)}</strong>
      </div>

      <div class="detail-item">
        <span>Data de envio</span>
        <strong>${formatDate(item.sentDate)}</strong>
      </div>

      <div class="detail-item full-width">
        <span>Link privado de entrega</span>
        <div class="detail-links">
          ${createLink(item.link, item.link ? "Abrir link de entrega" : "")}
        </div>
      </div>

      <div class="detail-item full-width">
        <span>Arquivos associados</span>
        <div class="detail-links">${fileLinks}</div>
      </div>

      <div class="detail-item">
        <span>Confirmação da cliente</span>
        <strong>${escapeHTML(deliveryConfirmation)}</strong>
      </div>

      <div class="detail-item">
        <span>Última atualização</span>
        <strong>${item.updatedAt ? new Date(item.updatedAt).toLocaleString("pt-BR") : "Não registrada"}</strong>
      </div>

      <div class="detail-item full-width">
        <span>Observações internas</span>
        <strong>${escapeHTML(item.notes || "Nenhuma observação registrada.")}</strong>
      </div>
    </div>
  `;

  openModal("detailModal");
}

function deleteDelivery(id) {
  const item = deliveries.find((delivery) => String(delivery.id) === String(id));
  if (!item) return;

  const confirmed = window.confirm(
    `Deseja excluir o trabalho "${item.title}"? Essa ação não poderá ser desfeita.`
  );

  if (!confirmed) return;

  const previousDeliveries = [...deliveries];
  deliveries = deliveries.filter((delivery) => String(delivery.id) !== String(id));

  if (!saveDeliveries()) {
    deliveries = previousDeliveries;
    return;
  }

  closeModal("detailModal");
  renderAll();
}

function refreshClients() {
  clients = loadClients();
  renderClientOptions($("deliveryClient").value);
}

function setupEvents() {
  $("newDeliveryBtn").addEventListener("click", openNewDelivery);
  $("emptyNewBtn").addEventListener("click", openNewDelivery);
  $("deliveryForm").addEventListener("submit", handleSaveDelivery);

  ["searchDelivery", "statusFilter", "deadlineFilter"].forEach((id) => {
    $(id).addEventListener(id === "searchDelivery" ? "input" : "change", renderDeliveries);
  });

  $("deliveriesTableBody").addEventListener("click", (event) => {
    const button = event.target.closest("[data-action]");
    if (!button) return;

    const id = button.dataset.id;

    if (button.dataset.action === "details") {
      showDetails(id);
    } else if (button.dataset.action === "edit") {
      openEditDelivery(id);
    }
  });

  $("editDeliveryBtn").addEventListener("click", () => {
    if (activeDetailId) openEditDelivery(activeDetailId);
  });

  document.querySelectorAll("[data-close]").forEach((button) => {
    button.addEventListener("click", () => closeModal(button.dataset.close));
  });

  document.querySelectorAll(".modal-backdrop").forEach((modal) => {
    modal.addEventListener("click", (event) => {
      if (event.target === modal) closeModal(modal.id);
    });
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      document.querySelectorAll(".modal-backdrop.open").forEach((modal) => {
        closeModal(modal.id);
      });
    }
  });

  $("mobileMenu").addEventListener("click", () => {
    $("sidebar").classList.toggle("open");
  });

  $("logoutBtn").addEventListener("click", () => {
    window.location.href = "login.html";
  });

  // Atualiza os nomes se a lista de clientes mudar em outra aba.
  window.addEventListener("storage", (event) => {
    if (event.key === CLIENTS_KEY) {
      refreshClients();
      renderAll();
    }
  });
}

function init() {
  renderClientOptions();
  setupEvents();
  renderAll();
}

init();
