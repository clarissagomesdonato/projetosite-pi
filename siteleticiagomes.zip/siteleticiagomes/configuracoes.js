"use strict";

const CHAVE_CONFIGURACOES = "leticia_configuracoes_v1";

const CHAVES_BACKUP = [
  "leticia_dashboard_v1",
  "leticia_clients_v1",
  "leticia_agenda_v1",
  "leticia_site_draft_v1",
  "leticia_site_published_v1",
  CHAVE_CONFIGURACOES
];

const CONFIGURACAO_PADRAO = {
  perfil: {
    nome: "Letícia Gomes",
    cargo: "Administradora",
    email: ""
  },

  contato: {
    telefone: "",
    whatsapp: "",
    emailContato: "",
    instagram: ""
  },

  preferencias: {
    formatoData: "dd/mm/aaaa",
    confirmarExclusao: true,
    mensagensAtivas: true
  },

  notificacoes: {
    solicitacoes: true,
    agenda: true,
    entregas: true,
    financeiro: false
  }
};

let temporizadorMensagem;

function clonar(objeto) {
  return JSON.parse(JSON.stringify(objeto));
}

function lerConfiguracoes() {
  try {
    const salvo = localStorage.getItem(CHAVE_CONFIGURACOES);

    if (!salvo) {
      return clonar(CONFIGURACAO_PADRAO);
    }

    const dados = JSON.parse(salvo);

    return {
      perfil: {
        ...CONFIGURACAO_PADRAO.perfil,
        ...(dados.perfil || {})
      },
      contato: {
        ...CONFIGURACAO_PADRAO.contato,
        ...(dados.contato || {})
      },
      preferencias: {
        ...CONFIGURACAO_PADRAO.preferencias,
        ...(dados.preferencias || {})
      },
      notificacoes: {
        ...CONFIGURACAO_PADRAO.notificacoes,
        ...(dados.notificacoes || {})
      }
    };
  } catch (erro) {
    console.error("Erro ao carregar configurações:", erro);
    return clonar(CONFIGURACAO_PADRAO);
  }
}

let configuracoes = lerConfiguracoes();

function mostrarMensagem(texto, tipo = "sucesso") {
  const elemento = document.getElementById("mensagem");

  if (!elemento) return;

  clearTimeout(temporizadorMensagem);

  elemento.textContent = texto;
  elemento.className = `mensagem visivel ${tipo}`;

  if (configuracoes.preferencias.mensagensAtivas) {
    temporizadorMensagem = setTimeout(() => {
      elemento.className = "mensagem";
      elemento.textContent = "";
    }, 5000);
  }
}

function salvarConfiguracoes(mensagem) {
  try {
    localStorage.setItem(
      CHAVE_CONFIGURACOES,
      JSON.stringify(configuracoes)
    );

    mostrarMensagem(mensagem);
    return true;
  } catch (erro) {
    console.error("Erro ao salvar:", erro);

    mostrarMensagem(
      "Não foi possível salvar. Verifique o espaço disponível no navegador.",
      "erro"
    );

    return false;
  }
}

function preencherCampo(id, valor) {
  const campo = document.getElementById(id);

  if (campo) {
    campo.value = valor ?? "";
  }
}

function preencherCheckbox(id, valor) {
  const campo = document.getElementById(id);

  if (campo) {
    campo.checked = Boolean(valor);
  }
}

/* CARREGAR DADOS NOS CAMPOS */

function carregarFormulario() {
  const { perfil, contato, preferencias, notificacoes } = configuracoes;

  preencherCampo("nome", perfil.nome);
  preencherCampo("cargo", perfil.cargo);
  preencherCampo("email", perfil.email);

  preencherCampo("telefone", contato.telefone);
  preencherCampo("whatsapp", contato.whatsapp);
  preencherCampo("emailContato", contato.emailContato);
  preencherCampo("instagram", contato.instagram);

  preencherCampo("formatoData", preferencias.formatoData);
  preencherCheckbox("confirmarExclusao", preferencias.confirmarExclusao);
  preencherCheckbox("mensagensAtivas", preferencias.mensagensAtivas);

  preencherCheckbox("notifSolicitacoes", notificacoes.solicitacoes);
  preencherCheckbox("notifAgenda", notificacoes.agenda);
  preencherCheckbox("notifEntregas", notificacoes.entregas);
  preencherCheckbox("notifFinanceiro", notificacoes.financeiro);
}

/* PERFIL */

document.getElementById("formPerfil").addEventListener("submit", (evento) => {
  evento.preventDefault();

  configuracoes.perfil = {
    nome: document.getElementById("nome").value.trim(),
    cargo: document.getElementById("cargo").value.trim(),
    email: document.getElementById("email").value.trim()
  };

  salvarConfiguracoes("Perfil salvo neste navegador.");
});

/* CONTATOS */

document.getElementById("formContato").addEventListener("submit", (evento) => {
  evento.preventDefault();

  configuracoes.contato = {
    telefone: document.getElementById("telefone").value.trim(),
    whatsapp: document.getElementById("whatsapp").value.trim(),
    emailContato: document.getElementById("emailContato").value.trim(),
    instagram: document.getElementById("instagram").value.trim()
  };

  salvarConfiguracoes("Dados de contato salvos neste navegador.");
});

/* SENHA */

document.getElementById("formSenha").addEventListener("submit", (evento) => {
  evento.preventDefault();

  const senhaAtual = document.getElementById("senhaAtual").value;
  const senhaNova = document.getElementById("senhaNova").value;
  const confirmarSenha = document.getElementById("confirmarSenha").value;

  if (senhaNova.length < 8) {
    mostrarMensagem(
      "A nova senha precisa ter pelo menos 8 caracteres.",
      "erro"
    );
    return;
  }

  if (senhaNova !== confirmarSenha) {
    mostrarMensagem(
      "As senhas novas não são iguais. Confira os campos.",
      "erro"
    );
    return;
  }

  if (senhaAtual === senhaNova) {
    mostrarMensagem(
      "Escolha uma senha diferente da senha atual.",
      "erro"
    );
    return;
  }

  /*
    A senha não é salva no localStorage.
    A alteração real exige autenticação no servidor.
  */

  mostrarMensagem(
    "Os campos foram validados, mas a senha não foi alterada. " +
    "Conecte esta função a um sistema de autenticação para concluir a alteração.",
    "erro"
  );
});

/* RECUPERAÇÃO DE ACESSO */

document.getElementById("btnRecuperacao").addEventListener("click", () => {
  const email = configuracoes.perfil.email.trim();

  if (!email) {
    mostrarMensagem(
      "Cadastre o e-mail da administradora no perfil antes de solicitar a recuperação.",
      "erro"
    );
    return;
  }

  mostrarMensagem(
    "O e-mail informado é " + email +
    ". Para enviar um link seguro de recuperação, é necessário configurar " +
    "um serviço de autenticação. Nenhum e-mail foi enviado.",
    "erro"
  );
});

/* PREFERÊNCIAS */

document.getElementById("formPreferencias").addEventListener("submit", (evento) => {
  evento.preventDefault();

  configuracoes.preferencias = {
    formatoData: document.getElementById("formatoData").value,
    confirmarExclusao: document.getElementById("confirmarExclusao").checked,
    mensagensAtivas: document.getElementById("mensagensAtivas").checked
  };

  salvarConfiguracoes("Preferências salvas neste navegador.");
});

/* NOTIFICAÇÕES */

document.getElementById("formNotificacoes").addEventListener("submit", (evento) => {
  evento.preventDefault();

  configuracoes.notificacoes = {
    solicitacoes: document.getElementById("notifSolicitacoes").checked,
    agenda: document.getElementById("notifAgenda").checked,
    entregas: document.getElementById("notifEntregas").checked,
    financeiro: document.getElementById("notifFinanceiro").checked
  };

  salvarConfiguracoes("Preferências de notificação salvas.");
});

/* EXPORTAR BACKUP */

document.getElementById("btnBackup").addEventListener("click", () => {
  const backup = {
    produto: "Painel administrativo - Letícia Gomes",
    versao: 1,
    exportadoEm: new Date().toISOString(),
    dados: {}
  };

  try {
    CHAVES_BACKUP.forEach((chave) => {
      const valor = localStorage.getItem(chave);

      if (valor !== null) {
        backup.dados[chave] = JSON.parse(valor);
      }
    });

    const arquivo = new Blob(
      [JSON.stringify(backup, null, 2)],
      { type: "application/json;charset=utf-8" }
    );

    const url = URL.createObjectURL(arquivo);
    const link = document.createElement("a");

    link.href = url;
    link.download = `backup-leticia-${new Date()
      .toISOString()
      .slice(0, 10)}.json`;

    document.body.appendChild(link);
    link.click();
    link.remove();

    URL.revokeObjectURL(url);

    mostrarMensagem("Backup exportado para o seu dispositivo.");
  } catch (erro) {
    console.error("Erro ao exportar backup:", erro);

    mostrarMensagem(
      "Não foi possível exportar os dados. Verifique se há informações inválidas.",
      "erro"
    );
  }
});

/* RESTAURAR BACKUP */

document.getElementById("btnRestaurar").addEventListener("click", async () => {
  const campoArquivo = document.getElementById("arquivoBackup");
  const arquivo = campoArquivo.files[0];

  if (!arquivo) {
    mostrarMensagem("Selecione um arquivo de backup primeiro.", "erro");
    return;
  }

  if (arquivo.size > 10 * 1024 * 1024) {
    mostrarMensagem(
      "O arquivo é muito grande. Selecione um backup de até 10 MB.",
      "erro"
    );
    return;
  }

  try {
    const conteudo = await arquivo.text();
    const backup = JSON.parse(conteudo);

    if (
      !backup ||
      backup.produto !== "Painel administrativo - Letícia Gomes" ||
      !backup.dados ||
      typeof backup.dados !== "object" ||
      Array.isArray(backup.dados)
    ) {
      throw new Error("Formato de backup inválido.");
    }

    const chavesPermitidas = CHAVES_BACKUP.filter((chave) =>
      Object.prototype.hasOwnProperty.call(backup.dados, chave)
    );

    if (chavesPermitidas.length === 0) {
      throw new Error("Nenhum dado reconhecido foi encontrado no backup.");
    }

    for (const chave of chavesPermitidas) {
      const valor = backup.dados[chave];

      if (
        valor === null ||
        typeof valor !== "object" ||
        Array.isArray(valor)
      ) {
        throw new Error("O arquivo contém dados em formato inválido.");
      }
    }

    const confirmado = window.confirm(
      "A restauração pode substituir dados existentes. " +
      "Recomendamos exportar um backup atual antes de continuar. " +
      "Deseja prosseguir?"
    );

    if (!confirmado) return;

    /*
      Salva o estado atual das chaves que serão alteradas,
      para tentar reverter se houver erro.
    */

    const estadoAnterior = {};

    chavesPermitidas.forEach((chave) => {
      estadoAnterior[chave] = localStorage.getItem(chave);
    });

    try {
      chavesPermitidas.forEach((chave) => {
        localStorage.setItem(
          chave,
          JSON.stringify(backup.dados[chave])
        );
      });
    } catch (erro) {
      chavesPermitidas.forEach((chave) => {
        const valorAnterior = estadoAnterior[chave];

        if (valorAnterior === null) {
          localStorage.removeItem(chave);
        } else {
          localStorage.setItem(chave, valorAnterior);
        }
      });

      throw erro;
    }

    configuracoes = lerConfiguracoes();
    carregarFormulario();

    campoArquivo.value = "";

    mostrarMensagem(
      "Backup restaurado. Recarregue as outras páginas do painel para atualizar os dados."
    );
  } catch (erro) {
    console.error("Erro ao restaurar backup:", erro);

    mostrarMensagem(
      "Não foi possível restaurar o arquivo. Verifique se ele é um backup válido deste painel.",
      "erro"
    );
  }
});

/* INICIALIZAÇÃO */

carregarFormulario();