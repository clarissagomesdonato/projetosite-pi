
/* ========================================
   1. ELEMENTOS DA PÁGINA
======================================== */

const loginForm = document.getElementById("loginForm");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");

const feedback = document.getElementById("feedback");
const togglePassword = document.getElementById("togglePassword");
const forgotPassword = document.getElementById("forgotPassword");

const year = document.getElementById("year");


/* ========================================
   2. ANO AUTOMÁTICO NO RODAPÉ
======================================== */

if (year) {
    year.textContent = new Date().getFullYear();
}


/* ========================================
   3. EXIBIR MENSAGENS
======================================== */

function showMessage(message, type = "error") {
    feedback.textContent = message;
    feedback.className = "feedback visible";

    if (type === "success") {
        feedback.style.color = "#376a4c";
    } else {
        feedback.style.color = "";
    }
}


/* ========================================
   4. MOSTRAR OU OCULTAR A SENHA
======================================== */

togglePassword.addEventListener("click", function () {
    const passwordVisible = passwordInput.type === "text";

    if (passwordVisible) {
        passwordInput.type = "password";
        togglePassword.textContent = "◉";
        togglePassword.setAttribute("aria-label", "Mostrar senha");
    } else {
        passwordInput.type = "text";
        togglePassword.textContent = "◎";
        togglePassword.setAttribute("aria-label", "Ocultar senha");
    }
});


/* ========================================
   5. RECUPERAÇÃO DE SENHA
======================================== */

forgotPassword.addEventListener("click", function () {
    const email = emailInput.value.trim();

    if (email === "") {
        showMessage("Digite seu e-mail para solicitar a recuperação de senha.");
        emailInput.focus();
        return;
    }

    if (!emailInput.checkValidity()) {
        showMessage("Digite um endereço de e-mail válido.");
        emailInput.focus();
        return;
    }

    showMessage(
        "A recuperação de senha será disponibilizada após a integração com o Firebase."
    );
});


/* ========================================
   6. VALIDAÇÃO DO FORMULÁRIO
======================================== */

loginForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const email = emailInput.value.trim();
    const password = passwordInput.value;

    // Verifica se os campos foram preenchidos.

    if (email === "" || password === "") {
        showMessage("Preencha o e-mail e a senha para continuar.");
        return;
    }

    // Verifica o formato do e-mail.

    if (!emailInput.checkValidity()) {
        showMessage("Confira se o e-mail foi digitado corretamente.");
        emailInput.focus();
        return;
    }

    /*
       PRÓXIMA ETAPA:
       Integrar o Firebase Authentication.

       O Firebase deverá validar as credenciais e,
       após o login, permitir o acesso ao painel administrativo.

       Não valide senhas manualmente nem armazene
       senhas no código JavaScript.
    */

    showMessage(
        "A interface está pronta! O acesso será liberado após a integração com o Firebase."
    );
});


/* CREDENCIAIS DA ADMINISTRADORA */
const EMAIL_ADMIN = "leticiagomesdonato2911@gmail.com";
const SENHA_ADMIN = "3245theo";

/* LOGIN */
loginForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const email = emailInput.value.trim();
    const senha = passwordInput.value;

    if (email === "" || senha === "") {
        showMessage("Preencha o e-mail e a senha.");
        return;
    }

    if (
        email === EMAIL_ADMIN &&
        senha === SENHA_ADMIN
    ) {
        showMessage("Login realizado! Entrando no painel...", "success");

        setTimeout(() => {
            window.location.href = "admin.html";
        }, 800);

    } else {
        showMessage("E-mail ou senha incorretos.");
    }
});
