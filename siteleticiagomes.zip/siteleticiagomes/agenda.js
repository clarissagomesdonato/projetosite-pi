/* ========================================
   AGENDA E PLANNER — LETÍCIA GOMES
======================================== */

(() => {
    "use strict";

    const STORAGE_KEY = "leticia_agenda_v1";
    const CLIENTS_KEY = "leticia_clients_v1";

    const $ = (id) => document.getElementById(id);

    const typeLabels = {
        shoot: "Ensaio confirmado",
        meeting: "Reunião",
        deadline: "Prazo de edição",
        task: "Tarefa"
    };

    const weekdays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

    const monthNames = [
        "janeiro", "fevereiro", "março", "abril",
        "maio", "junho", "julho", "agosto",
        "setembro", "outubro", "novembro", "dezembro"
    ];

    let selectedDate = startOfDay(new Date());
    let currentView = "month";
    let activeEventId = null;
    let events = loadEvents();

    /* ========================================
       FUNÇÕES AUXILIARES
    ======================================== */

    function dateKey(date) {
        return [
            date.getFullYear(),
            String(date.getMonth() + 1).padStart(2, "0"),
            String(date.getDate()).padStart(2, "0")
        ].join("-");
    }

    function startOfDay(date) {
        return new Date(
            date.getFullYear(),
            date.getMonth(),
            date.getDate()
        );
    }

    function addDays(date, amount) {
        const result = new Date(date);
        result.setDate(result.getDate() + amount);
        return result;
    }

    function startOfWeek(date) {
        const result = startOfDay(date);
        result.setDate(result.getDate() - result.getDay());
        return result;
    }

    function dateFromKey(key) {
        const [year, month, day] = String(key).split("-").map(Number);

        return new Date(
            year,
            (month || 1) - 1,
            day || 1
        );
    }

    function isSameDay(dateA, dateB) {
        return dateKey(dateA) === dateKey(dateB);
    }

    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g, (character) => {
            const entities = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            };

            return entities[character];
        });
    }

    function makeId() {
        if (window.crypto && window.crypto.randomUUID) {
            return window.crypto.randomUUID();
        }

        return `evento_${Date.now()}_${Math.random()
            .toString(16)
            .slice(2)}`;
    }

    function formatDate(date, options = {
        day: "numeric",
        month: "long",
        year: "numeric"
    }) {
        return new Intl.DateTimeFormat("pt-BR", options).format(date);
    }

    function formatDuration(minutes) {
        if (!minutes) {
            return "Dia inteiro / sem horário";
        }

        if (minutes < 60) {
            return `${minutes} minutos`;
        }

        const hours = Math.floor(minutes / 60);
        const remainingMinutes = minutes % 60;

        if (!remainingMinutes) {
            return `${hours} hora${hours > 1 ? "s" : ""}`;
        }

        return `${hours}h${String(remainingMinutes).padStart(2, "0")}`;
    }

    function getTimeLabel(event) {
        return event.time || "Sem horário";
    }

    function sortEvents(list) {
        return [...list].sort((a, b) => {
            const dateA = `${a.date}T${a.time || "23:59"}`;
            const dateB = `${b.date}T${b.time || "23:59"}`;

            return dateA.localeCompare(dateB);
        });
    }

    /* ========================================
       SALVAMENTO E CARREGAMENTO
    ======================================== */

    function normalizeEvent(event) {
        return {
            id: event.id || makeId(),
            title: String(event.title || "Compromisso sem título"),

            type: ["shoot", "meeting", "deadline", "task"]
                .includes(event.type)
                ? event.type
                : "task",

            date: event.date || dateKey(new Date()),
            time: event.time || "",
            duration: Number(event.duration ?? 60),

            clientId: event.clientId || "",
            clientName: event.clientName || "",
            notes: event.notes || "",

            completed: Boolean(event.completed),

            createdAt: event.createdAt || new Date().toISOString(),
            updatedAt: event.updatedAt || new Date().toISOString()
        };
    }

    function loadEvents() {
        try {
            const saved = JSON.parse(
                localStorage.getItem(STORAGE_KEY) || "[]"
            );

            if (!Array.isArray(saved)) {
                return [];
            }

            return saved.map(normalizeEvent);

        } catch (error) {
            console.error("Erro ao carregar a agenda:", error);
            return [];
        }
    }

    function saveEvents() {
        try {
            localStorage.setItem(
                STORAGE_KEY,
                JSON.stringify(events)
            );

            renderAll();

        } catch (error) {
            console.error("Erro ao salvar a agenda:", error);

            alert(
                "Não foi possível salvar os compromissos. " +
                "Verifique o armazenamento do navegador."
            );
        }
    }

    function loadClients() {
        try {
            const saved = JSON.parse(
                localStorage.getItem(CLIENTS_KEY) || "[]"
            );

            return Array.isArray(saved) ? saved : [];

        } catch (error) {
            console.error("Erro ao carregar clientes:", error);
            return [];
        }
    }

    function getClientName(clientId) {
        if (!clientId) {
            return "";
        }

        const client = loadClients().find(
            (item) => String(item.id) === String(clientId)
        );

        return client ? client.name || "" : "";
    }

    function getEventClientName(event) {
        return event.clientName || getClientName(event.clientId);
    }

    function getEventsForDate(date) {
        return sortEvents(
            events.filter((event) => event.date === date)
        );
    }

    /* ========================================
       ATUALIZAÇÃO GERAL
    ======================================== */

    function renderAll() {
        $("todayLabel").textContent =
            `Hoje, ${formatDate(new Date(), {
                day: "numeric",
                month: "short"
            })}`;

        renderStats();
        renderCalendar();
        renderUpcoming();
        renderTaskPreview();
    }

    function renderStats() {
        const monthEvents = events.filter((event) => {
            const date = dateFromKey(event.date);

            return (
                date.getFullYear() === selectedDate.getFullYear() &&
                date.getMonth() === selectedDate.getMonth()
            );
        });

        $("monthCount").textContent = monthEvents.length;

        $("shootCount").textContent = monthEvents.filter(
            (event) => event.type === "shoot" && !event.completed
        ).length;

        $("pendingCount").textContent = events.filter(
            (event) => event.type === "task" && !event.completed
        ).length;
    }

    /* ========================================
       NAVEGAÇÃO DO CALENDÁRIO
    ======================================== */

    function setView(view) {
        currentView = view;

        document.querySelectorAll("[data-view]").forEach((button) => {
            button.classList.toggle(
                "selected",
                button.dataset.view === view
            );
        });

        renderCalendar();
    }

    function changePeriod(direction) {
        if (currentView === "month") {
            selectedDate = new Date(
                selectedDate.getFullYear(),
                selectedDate.getMonth() + direction,
                1
            );

        } else if (currentView === "week") {
            selectedDate = addDays(selectedDate, 7 * direction);

        } else {
            selectedDate = addDays(selectedDate, direction);
        }

        renderCalendar();
        renderStats();
    }

    function renderCalendar() {
        const title = $("periodTitle");
        const content = $("calendarContent");

        if (currentView === "month") {
            const month = monthNames[selectedDate.getMonth()];

            title.textContent =
                `${month.charAt(0).toUpperCase()}${month.slice(1)} ` +
                selectedDate.getFullYear();

            content.innerHTML = renderMonth();

        } else if (currentView === "week") {
            const start = startOfWeek(selectedDate);
            const end = addDays(start, 6);

            title.textContent =
                `${formatDate(start, {
                    day: "numeric",
                    month: "short"
                })} – ${formatDate(end, {
                    day: "numeric",
                    month: "short",
                    year: "numeric"
                })}`;

            content.innerHTML = renderWeek(start);

        } else if (currentView === "day") {
            title.textContent = formatDate(selectedDate);

            content.innerHTML = renderDay(selectedDate);

        } else {
            title.textContent = "Planner de tarefas";

            content.innerHTML = renderTaskPlanner();
        }

        renderStats();
    }

    /* ========================================
       VISUALIZAÇÃO MENSAL
    ======================================== */

    function renderMonth() {
        const firstDay = new Date(
            selectedDate.getFullYear(),
            selectedDate.getMonth(),
            1
        );

        const gridStart = startOfWeek(firstDay);

        let html = '<div class="month-grid">';

        weekdays.forEach((day) => {
            html += `<div class="weekday-label">${day}</div>`;
        });

        for (let index = 0; index < 42; index++) {
            const date = addDays(gridStart, index);
            const key = dateKey(date);

            const classes = ["month-cell"];

            if (date.getMonth() !== selectedDate.getMonth()) {
                classes.push("outside");
            }

            if (isSameDay(date, new Date())) {
                classes.push("is-today");
            }

            html += `
                <div
                    class="${classes.join(" ")}"
                    data-date="${key}"
                    role="button"
                    tabindex="0"
                    aria-label="${escapeHTML(formatDate(date))}"
                >
                    <div class="day-number">${date.getDate()}</div>
            `;

            const dayEvents = getEventsForDate(key);

            dayEvents.slice(0, 3).forEach((event) => {
                html += `
                    <button
                        class="month-event ${event.type} ${
                            event.completed ? "completed" : ""
                        }"
                        data-event-id="${escapeHTML(event.id)}"
                        type="button"
                        title="${escapeHTML(event.title)}"
                    >
                        ${event.completed ? "✓ " : ""}
                        ${escapeHTML(
                            event.time
                                ? `${event.time} · ${event.title}`
                                : event.title
                        )}
                    </button>
                `;
            });

            if (dayEvents.length > 3) {
                html += `
                    <div class="more-events">
                        +${dayEvents.length - 3} mais
                    </div>
                `;
            }

            html += "</div>";
        }

        html += "</div>";

        return html;
    }

    /* ========================================
       VISUALIZAÇÃO SEMANAL
    ======================================== */

    function renderWeek(start) {
        const hours = Array.from(
            { length: 13 },
            (_, index) => index + 7
        );

        let html = '<div class="week-grid">';
        html += '<div class="week-head">Hora</div>';

        for (let index = 0; index < 7; index++) {
            const date = addDays(start, index);

            html += `
                <div class="week-head ${
                    isSameDay(date, new Date()) ? "is-today" : ""
                }">
                    ${weekdays[date.getDay()]}
                    <strong>${date.getDate()}</strong>
                </div>
            `;
        }

        hours.forEach((hour) => {
            const formattedHour = String(hour).padStart(2, "0");

            html += `
                <div class="time-label">
                    ${formattedHour}:00
                </div>
            `;

            for (let index = 0; index < 7; index++) {
                const date = addDays(start, index);
                const key = dateKey(date);

                const matchingEvents = getEventsForDate(key).filter(
                    (event) =>
                        event.time &&
                        Number(event.time.slice(0, 2)) === hour
                );

                html += `
                    <div
                        class="week-slot"
                        data-date="${key}"
                        data-time="${formattedHour}:00"
                        title="Clique para adicionar um compromisso"
                    >
                `;

                matchingEvents.forEach((event) => {
                    html += `
                        <button
                            class="week-event ${event.type}"
                            data-event-id="${escapeHTML(event.id)}"
                            type="button"
                            title="${escapeHTML(event.title)}"
                        >
                            ${escapeHTML(event.title)}
                        </button>
                    `;
                });

                html += "</div>";
            }
        });

        html += "</div>";

        return html;
    }

    /* ========================================
       VISUALIZAÇÃO DIÁRIA
    ======================================== */

    function renderDay(date) {
        const list = getEventsForDate(dateKey(date));

        let html = `
            <div class="day-view">
                <div class="day-banner">
                    <strong>
                        ${escapeHTML(formatDate(date, {
                            weekday: "long",
                            day: "numeric",
                            month: "long"
                        }))}
                    </strong>

                    <span>${list.length} compromisso(s)</span>
                </div>
        `;

        if (!list.length) {
            return html + `
                <div class="empty-state">
                    <strong>Dia livre por aqui ✦</strong>
                    Nenhum compromisso cadastrado para esta data.
                </div>
            </div>`;
        }

        list.forEach((event) => {
            const client = getEventClientName(event);

            html += `
                <div class="day-item">
                    <div class="day-time">
                        ${escapeHTML(getTimeLabel(event))}
                        <br>
                        <span class="muted">
                            ${escapeHTML(formatDuration(event.duration))}
                        </span>
                    </div>

                    <div class="day-event ${event.type}">
                        <h3>
                            ${event.completed ? "✓ " : ""}
                            ${escapeHTML(event.title)}
                        </h3>

                        <p>
                            ${escapeHTML(typeLabels[event.type])}
                            ${client ? ` · ${escapeHTML(client)}` : ""}
                        </p>

                        ${
                            event.notes
                                ? `<p>${escapeHTML(event.notes)}</p>`
                                : ""
                        }

                        <div class="event-actions">
                            <button
                                class="mini-action"
                                data-open-event="${escapeHTML(event.id)}"
                                type="button"
                            >
                                Ver detalhes
                            </button>

                            <button
                                class="mini-action"
                                data-toggle-event="${escapeHTML(event.id)}"
                                type="button"
                            >
                                ${event.completed ? "Reabrir" : "Concluir"}
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });

        html += "</div>";

        return html;
    }

    /* ========================================
       PLANNER DE TAREFAS
    ======================================== */

    function renderTaskPlanner() {
        const tasks = sortEvents(
            events.filter(
                (event) =>
                    event.type === "task" ||
                    event.type === "deadline"
            )
        );

        if (!tasks.length) {
            return `
                <div class="empty-state">
                    <strong>Seu planner começa aqui ✦</strong>
                    Adicione tarefas e prazos para organizar a semana.
                </div>
            `;
        }

        const pending = tasks.filter((event) => !event.completed);
        const completed = tasks.filter((event) => event.completed);

        function createTaskHTML(event) {
            const client = getEventClientName(event);

            return `
                <div class="planner-task ${
                    event.completed ? "done" : ""
                }">
                    <input
                        type="checkbox"
                        data-toggle-event="${escapeHTML(event.id)}"
                        ${event.completed ? "checked" : ""}
                        aria-label="Marcar tarefa como concluída"
                    >

                    <div class="task-main">
                        <div class="task-title">
                            ${escapeHTML(event.title)}
                        </div>

                        <span class="task-meta">
                            ${escapeHTML(formatDate(
                                dateFromKey(event.date),
                                { day: "numeric", month: "short" }
                            ))}
                            ${event.time ? ` · ${escapeHTML(event.time)}` : ""}
                            ${client ? ` · ${escapeHTML(client)}` : ""}
                        </span>
                    </div>

                    <span class="task-tag">
                        ${event.type === "deadline" ? "Prazo" : "Tarefa"}
                    </span>

                    <button
                        class="mini-action"
                        data-open-event="${escapeHTML(event.id)}"
                        type="button"
                    >
                        Abrir
                    </button>
                </div>
            `;
        }

        return `
            <div class="task-planner">

                <p class="eyebrow">
                    PENDENTES · ${pending.length}
                </p>

                ${
                    pending.length
                        ? pending.map(createTaskHTML).join("")
                        : '<div class="empty-state">Tudo em dia! ✦</div>'
                }

                <p class="eyebrow" style="margin-top: 12px">
                    CONCLUÍDAS · ${completed.length}
                </p>

                ${completed.map(createTaskHTML).join("")}

            </div>
        `;
    }

    /* ========================================
       PRÓXIMOS COMPROMISSOS
    ======================================== */

    function renderUpcoming() {
        const todayKey = dateKey(new Date());

        const upcoming = sortEvents(
            events.filter(
                (event) =>
                    event.date >= todayKey &&
                    !event.completed
            )
        ).slice(0, 5);

        if (!upcoming.length) {
            $("upcomingList").innerHTML = `
                <div class="empty-state">
                    <strong>Nenhum compromisso próximo</strong>
                    Que tal planejar os próximos dias?
                </div>
            `;

            return;
        }

        $("upcomingList").innerHTML = upcoming.map((event) => {
            const date = dateFromKey(event.date);
            const client = getEventClientName(event);

            return `
                <div class="upcoming-item">
                    <div class="date-square">
                        <strong>${date.getDate()}</strong>
                        <small>${monthNames[date.getMonth()].slice(0, 3)}</small>
                    </div>

                    <div class="upcoming-info">
                        <strong>${escapeHTML(event.title)}</strong>

                        <small>
                            ${escapeHTML(getTimeLabel(event))}
                            · ${escapeHTML(typeLabels[event.type])}
                        </small>
                    </div>

                    <span class="type-pill">
                        ${escapeHTML(client || "Estúdio")}
                    </span>
                </div>
            `;
        }).join("");
    }

    /* ========================================
       LISTA RÁPIDA DE TAREFAS
    ======================================== */

    function renderTaskPreview() {
        const tasks = sortEvents(
            events.filter(
                (event) =>
                    event.type === "task" &&
                    !event.completed
            )
        ).slice(0, 4);

        if (!tasks.length) {
            $("taskPreview").innerHTML = `
                <div class="empty-state">
                    Nenhuma tarefa pendente. Respira, diva! ✦
                </div>
            `;

            return;
        }

        $("taskPreview").innerHTML = tasks.map((event) => `
            <label class="preview-task">
                <input
                    type="checkbox"
                    data-toggle-event="${escapeHTML(event.id)}"
                >

                <span>${escapeHTML(event.title)}</span>

                <small class="muted">
                    ${escapeHTML(formatDate(
                        dateFromKey(event.date),
                        { day: "numeric", month: "short" }
                    ))}
                </small>
            </label>
        `).join("");
    }

    /* ========================================
       CLIENTES
    ======================================== */

    function populateClients(selectedId = "") {
        const clients = loadClients().sort((a, b) =>
            String(a.name || "").localeCompare(
                String(b.name || ""),
                "pt-BR"
            )
        );

        $("eventClient").innerHTML = `
            <option value="">Sem cliente vinculado</option>
            ${clients.map((client) => `
                <option value="${escapeHTML(client.id)}">
                    ${escapeHTML(client.name || "Cliente sem nome")}
                </option>
            `).join("")}
        `;

        $("eventClient").value = selectedId || "";
    }

    /* ========================================
       ABRIR E FECHAR MODAIS
    ======================================== */

    function showModal(id) {
        $(id).classList.add("open");
        $(id).setAttribute("aria-hidden", "false");
    }

    function hideModal(id) {
        $(id).classList.remove("open");
        $(id).setAttribute("aria-hidden", "true");
    }

    function openEventModal(event = null, preset = {}) {
        $("eventForm").reset();

        $("eventId").value = event?.id || "";

        $("modalTitle").textContent = event
            ? "Editar compromisso"
            : preset.type === "task"
                ? "Nova tarefa"
                : "Novo compromisso";

        $("eventTitle").value = event?.title || preset.title || "";

        $("eventType").value =
            event?.type || preset.type || "shoot";

        $("eventDate").value =
            event?.date || preset.date || dateKey(selectedDate);

        $("eventTime").value =
            event?.time || preset.time || "09:00";

        $("eventDuration").value = String(
            event?.duration ?? preset.duration ?? 60
        );

        $("eventNotes").value = event?.notes || "";

        $("eventCompleted").checked =
            Boolean(event?.completed);

        populateClients(
            event?.clientId || preset.clientId || ""
        );

        updateFormType();

        showModal("eventModal");
    }

    function updateFormType() {
        const type = $("eventType").value;

        $("completedField").style.display =
            type === "task" || type === "deadline"
                ? "flex"
                : "none";

        $("eventFormHint").textContent =
            type === "shoot"
                ? "Cadastre aqui apenas ensaios que já foram aprovados e confirmados."
                : "O compromisso ficará salvo nesta agenda do navegador.";
    }

    /* ========================================
       DETALHES DO COMPROMISSO
    ======================================== */

    function showDetails(id) {
        const event = events.find((item) => item.id === id);

        if (!event) {
            return;
        }

        activeEventId = id;

        const client = getEventClientName(event);

        $("detailTitle").textContent = event.title;

        $("eventDetailBody").innerHTML = `
            <span class="detail-badge">
                ${escapeHTML(typeLabels[event.type])}
            </span>

            <div class="detail-list">

                <div class="detail-row">
                    <span>Data</span>
                    <strong>
                        ${escapeHTML(formatDate(dateFromKey(event.date)))}
                    </strong>
                </div>

                <div class="detail-row">
                    <span>Horário</span>
                    <strong>
                        ${escapeHTML(getTimeLabel(event))}
                        · ${escapeHTML(formatDuration(event.duration))}
                    </strong>
                </div>

                <div class="detail-row">
                    <span>Cliente</span>
                    <strong>
                        ${escapeHTML(client || "Nenhum cliente vinculado")}
                    </strong>
                </div>

                <div class="detail-row">
                    <span>Status</span>
                    <strong>
                        ${event.completed ? "Concluído" : "Pendente"}
                    </strong>
                </div>

                <div class="detail-row">
                    <span>Observações</span>
                    <div class="detail-notes">
                        ${escapeHTML(
                            event.notes || "Nenhuma observação adicionada."
                        )}
                    </div>
                </div>

            </div>

            ${
                event.completed
                    ? '<p class="completed-note">✓ Esta atividade está marcada como concluída.</p>'
                    : ""
            }
        `;

        showModal("eventDetailModal");
    }

    /* ========================================
       CONCLUIR E EXCLUIR
    ======================================== */

    function toggleEvent(id) {
        const event = events.find((item) => item.id === id);

        if (!event) {
            return;
        }

        event.completed = !event.completed;
        event.updatedAt = new Date().toISOString();

        saveEvents();

        if ($("eventDetailModal").classList.contains("open")) {
            showDetails(id);
        }
    }

    function deleteEvent(id) {
        if (!id) {
            return;
        }

        const event = events.find((item) => item.id === id);

        if (!event) {
            return;
        }

        const confirmed = confirm(
            `Deseja excluir "${event.title}" da agenda?`
        );

        if (!confirmed) {
            return;
        }

        events = events.filter((item) => item.id !== id);

        saveEvents();

        hideModal("eventDetailModal");

        activeEventId = null;
    }

    /* ========================================
       EVENTOS DA INTERFACE
    ======================================== */

    function bindEvents() {

        // Novo compromisso e nova tarefa

        $("newEventBtn").addEventListener("click", () => {
            openEventModal();
        });

        $("newTaskBtn").addEventListener("click", () => {
            openEventModal(null, { type: "task" });
        });

        // Navegação entre datas

        $("prevDate").addEventListener("click", () => {
            changePeriod(-1);
        });

        $("nextDate").addEventListener("click", () => {
            changePeriod(1);
        });

        $("goToday").addEventListener("click", () => {
            selectedDate = startOfDay(new Date());
            renderAll();
        });

        // Alternância entre visualizações

        document.querySelectorAll("[data-view]").forEach((button) => {
            button.addEventListener("click", () => {
                setView(button.dataset.view);
            });
        });

        $("seeAllBtn").addEventListener("click", () => {
            setView("week");
        });

        // Campos que mudam conforme o tipo

        $("eventType").addEventListener("change", updateFormType);

        // Salvar formulário

        $("eventForm").addEventListener("submit", (event) => {
            event.preventDefault();

            const id = $("eventId").value;

            const existing = events.find(
                (item) => item.id === id
            );

            const clientId = $("eventClient").value;
            const clientName = getClientName(clientId);
            const type = $("eventType").value;

            const title = $("eventTitle").value.trim();
            const date = $("eventDate").value;

            if (!title) {
                alert("Digite um título para o compromisso.");
                return;
            }

            if (!date) {
                alert("Escolha a data do compromisso.");
                return;
            }

            /*
             * Proteção contra ensaios não aprovados:
             * a Letícia precisa confirmar antes de salvar
             * um compromisso do tipo ensaio.
             */

            if (
                type === "shoot" &&
                !confirm(
                    "Você confirma que este ensaio já foi aprovado " +
                    "pela cliente e está fechado?"
                )
            ) {
                return;
            }

            const newEvent = normalizeEvent({
                ...(existing || {}),

                id: id || makeId(),
                title,
                type,
                date,

                time: $("eventTime").value,
                duration: Number($("eventDuration").value),

                clientId,
                clientName,

                notes: $("eventNotes").value.trim(),
                completed: $("eventCompleted").checked,

                createdAt:
                    existing?.createdAt || new Date().toISOString(),

                updatedAt: new Date().toISOString()
            });

            if (existing) {
                events = events.map((item) =>
                    item.id === id ? newEvent : item
                );
            } else {
                events.push(newEvent);
            }

            selectedDate = dateFromKey(newEvent.date);

            hideModal("eventModal");

            saveEvents();
        });

        // Fechar modais

        document.querySelectorAll("[data-close]").forEach((button) => {
            button.addEventListener("click", () => {
                hideModal(button.dataset.close);
            });
        });

        document.querySelectorAll(".modal-backdrop").forEach((modal) => {
            modal.addEventListener("click", (event) => {
                if (event.target === modal) {
                    hideModal(modal.id);
                }
            });
        });

        // Ações do calendário e do planner

        $("calendarContent").addEventListener("click", (event) => {

            const eventButton = event.target.closest("[data-event-id]");

            if (eventButton) {
                event.stopPropagation();
                showDetails(eventButton.dataset.eventId);
                return;
            }

            const openButton = event.target.closest("[data-open-event]");

            if (openButton) {
                showDetails(openButton.dataset.openEvent);
                return;
            }

            const toggleButton = event.target.closest("[data-toggle-event]");

            if (toggleButton) {
                toggleEvent(toggleButton.dataset.toggleEvent);
                return;
            }

            const cell = event.target.closest("[data-date]");

            if (!cell) {
                return;
            }

            // No mês, clicar em um dia abre a visualização diária.

            if (currentView === "month") {
                selectedDate = dateFromKey(cell.dataset.date);
                setView("day");
                return;
            }

            // Na semana, clicar em um horário inicia uma reunião.

            if (currentView === "week" && cell.dataset.time) {
                openEventModal(null, {
                    date: cell.dataset.date,
                    time: cell.dataset.time,
                    type: "meeting"
                });
            }
        });

        // Acessibilidade: Enter ou espaço abre o dia.

        $("calendarContent").addEventListener("keydown", (event) => {
            if (
                (event.key === "Enter" || event.key === " ") &&
                event.target.matches(".month-cell")
            ) {
                event.preventDefault();

                selectedDate = dateFromKey(event.target.dataset.date);
                setView("day");
            }
        });

        // Marcar tarefas concluídas.

        $("taskPreview").addEventListener("change", (event) => {
            const checkbox = event.target.closest("[data-toggle-event]");

            if (checkbox) {
                toggleEvent(checkbox.dataset.toggleEvent);
            }
        });

        $("calendarContent").addEventListener("change", (event) => {
            const checkbox = event.target.closest("[data-toggle-event]");

            if (checkbox) {
                toggleEvent(checkbox.dataset.toggleEvent);
            }
        });

        // Editar e excluir pelo modal de detalhes.

        $("editEventBtn").addEventListener("click", () => {
            const event = events.find(
                (item) => item.id === activeEventId
            );

            if (!event) {
                return;
            }

            hideModal("eventDetailModal");
            openEventModal(event);
        });

        $("deleteEventBtn").addEventListener("click", () => {
            deleteEvent(activeEventId);
        });

        // Menu para celular.

        $("mobileMenu").addEventListener("click", () => {
            $("sidebar").classList.toggle("open");
        });

        document.addEventListener("click", (event) => {
            const sidebar = $("sidebar");

            if (
                window.innerWidth <= 760 &&
                sidebar.classList.contains("open") &&
                !sidebar.contains(event.target) &&
                event.target !== $("mobileMenu")
            ) {
                sidebar.classList.remove("open");
            }
        });

        // Atualizar lista de clientes quando outro separador mudar os dados.

        window.addEventListener("storage", (event) => {
            if (event.key === CLIENTS_KEY) {
                const selectedClient = $("eventClient").value;
                populateClients(selectedClient);
            }

            if (event.key === STORAGE_KEY) {
                events = loadEvents();
                renderAll();
            }
        });

        // Sair do painel.

        $("logoutBtn").addEventListener("click", () => {
            if (confirm("Deseja sair do painel?")) {
                window.location.href = "login.html";
            }
        });
    }

    /* ========================================
       INICIALIZAÇÃO
    ======================================== */

    bindEvents();
    populateClients();
    renderAll();

})();