
/* =========================================
   01. ARMAZENAMENTO COMPARTILHADO
========================================= */

const STORAGE_KEY = "leticia_dashboard_v1";

const $ = (id) => document.getElementById(id);

function loadData() {
    try {
        const saved = localStorage.getItem(STORAGE_KEY);

        if (saved) {
            const parsed = JSON.parse(saved);

            if (
                parsed &&
                Array.isArray(parsed.requests) &&
                Array.isArray(parsed.sessions) &&
                Array.isArray(parsed.deliveries) &&
                Array.isArray(parsed.tasks) &&
                Array.isArray(parsed.finances)
            ) {
                return parsed;
            }
        }
    } catch (error) {
        console.error("Erro ao carregar os dados:", error);
    }

    const initialData = {
        requests: [],
        sessions: [],
        deliveries: [],
        tasks: [],
        finances: []
    };

    localStorage.setItem(STORAGE_KEY, JSON.stringify(initialData));
    return initialData;
}

let data = loadData();

function saveData() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
        return true;
    } catch (error) {
        console.error("Erro ao salvar os dados:", error);
        alert("Não foi possível salvar. Verifique o armazenamento do navegador.");
        return false;
    }
}

/* =========================================
   02. PADRONIZAÇÃO DAS SOLICITAÇÕES
========================================= */

const VALID_STATUSES = [
    "Nova",
    "Em negociação",
    "Proposta enviada",
    "Confirmada",
    "Encerrada"
];

const VALID_PROPOSAL_STATUSES = [
    "Não elaborada",
    "Rascunho",
    "Enviada",
    "Aceita",
    "Recusada"
];

function normalizeRequest(item) {
    const validStatus = VALID_STATUSES.includes(item.status)
        ? item.status
        : "Nova";

    const validProposalStatus =
        VALID_PROPOSAL_STATUSES.includes(item.proposalStatus)
            ? item.proposalStatus
            : "Não elaborada";

    return {
        id: item.id ?? Date.now() + Math.floor(Math.random() * 1000),
        name: String(item.name || ""),
        email: String(item.email || ""),
        phone: String(item.phone || ""),
        service: String(item.service || ""),
        date: String(item.date || ""),
        notes: String(item.notes || ""),
        status: validStatus,
        proposalStatus: validProposalStatus,
        proposalAmount: Number(item.proposalAmount || 0),
        proposalValidity: String(item.proposalValidity || ""),
        proposalConditions: String(item.proposalConditions || "")
    };
}

data.requests = data.requests.map(normalizeRequest);

/* Salva os campos novos sem apagar as outras áreas do painel. */
saveData();

/* =========================================
   03. FUNÇÕES AUXILIARES
========================================= */

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, (character) => {
        const entities = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        };

        return entities[character];
    });
}

function formatCurrency(value) {
    return Number(value || 0).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
}

function formatDate(value) {
    if (!value) return "Não informada";

    const parts = value.split("-").map(Number);
    const date = new Date(parts[0], parts[1] - 1, parts[2]);

    return date.toLocaleDateString("pt-BR");
}

function initials(name) {
    const words = String(name || "").trim().split(/\s+/);

    return words
        .slice(0, 2)
        .map(word => word.charAt(0))
        .join("")
        .toUpperCase();
}

function proposalLabel(item) {
    if (item.proposalStatus !== "Não elaborada") {
        return item.proposalStatus;
    }

    return "Não elaborada";
}

function getStatusClass(status) {
    const classes = {
        "Nova": "status-new",
        "Em negociação": "status-negotiation",
        "Proposta enviada": "status-proposal",
        "Confirmada": "status-confirmed",
        "Encerrada": "status-closed",
        "Enviada": "status-proposal",
        "Aceita": "status-confirmed",
        "Recusada": "status-refused",
        "Rascunho": "status-negotiation",
        "Não elaborada": "status-closed"
    };

    return classes[status] || "status-closed";
}

function normalizeSearch(value) {
    return String(value || "")
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .trim();
}

/* =========================================
   04. DATA E NAVEGAÇÃO
========================================= */

$("year").textContent = new Date().getFullYear();

$("logoutButton").addEventListener("click", function () {
    window.location.href = "login.html";
});

const sidebar = $("sidebar");
const menuButton = $("menuButton");
const overlay = $("mobileOverlay");

function closeMenu() {
    sidebar.classList.remove("open");
    overlay.classList.remove("visible");
    menuButton.setAttribute("aria-expanded", "false");
}

menuButton.addEventListener("click", function () {
    const open = sidebar.classList.toggle("open");

    overlay.classList.toggle("visible", open);
    menuButton.setAttribute("aria-expanded", String(open));
});

overlay.addEventListener("click", closeMenu);

sidebar.querySelectorAll(".nav-link").forEach(link => {
    link.addEventListener("click", closeMenu);
});

/* =========================================
   05. INDICADORES COMERCIAIS
========================================= */

function renderSummary() {
    $("countNew").textContent = data.requests.filter(
        item => item.status === "Nova"
    ).length;

    $("countNegotiation").textContent = data.requests.filter(
        item => item.status === "Em negociação"
    ).length;

    $("countProposals").textContent = data.requests.filter(
        item => item.status === "Proposta enviada"
    ).length;

    $("countConfirmed").textContent = data.requests.filter(
        item => item.status === "Confirmada"
    ).length;
}

/* =========================================
   06. TABELA DE SOLICITAÇÕES
========================================= */

function renderRequests() {
    const search = normalizeSearch($("searchInput").value);
    const statusFilter = $("statusFilter").value;
    const proposalFilter = $("proposalFilter").value;

    const filtered = data.requests
        .filter(item => {
            const searchableText = normalizeSearch([
                item.name,
                item.email,
                item.phone,
                item.service,
                item.notes
            ].join(" "));

            const matchesSearch = searchableText.includes(search);
            const matchesStatus =
                !statusFilter || item.status === statusFilter;
            const matchesProposal =
                !proposalFilter || item.proposalStatus === proposalFilter;

            return matchesSearch && matchesStatus && matchesProposal;
        })
        .slice()
        .sort((a, b) => Number(b.id) - Number(a.id));

    $("resultCount").textContent =
        `${filtered.length} ${filtered.length === 1 ? "registro" : "registros"}`;

    $("emptyState").classList.toggle("hidden", filtered.length > 0);
    $("requestsTableBody").classList.toggle("hidden", filtered.length === 0);

    $("requestsTableBody").innerHTML = filtered.map(item => `
        <tr>
            <td>
                <div class="client-cell">
                    <div class="client-avatar">
                        ${escapeHTML(initials(item.name))}
                    </div>

                    <div>
                        <strong>${escapeHTML(item.name)}</strong>
                        <small>${escapeHTML(item.email || item.phone || "Sem contato cadastrado")}</small>
                    </div>
                </div>
            </td>

            <td>${escapeHTML(item.service || "Não informado")}</td>

            <td>${escapeHTML(formatDate(item.date))}</td>

            <td>
                <span class="status-badge ${getStatusClass(item.status)}">
                    ${escapeHTML(item.status)}
                </span>
            </td>

            <td>
                <span class="status-badge ${getStatusClass(proposalLabel(item))}">
                    ${escapeHTML(proposalLabel(item))}
                </span>
                ${item.proposalAmount > 0
                    ? `<small class="proposal-value">${escapeHTML(formatCurrency(item.proposalAmount))}</small>`
                    : ""}
            </td>

            <td>
                <button
                    type="button"
                    class="table-action"
                    data-edit-request="${Number(item.id)}"
                >Abrir ficha</button>
            </td>
        </tr>
    `).join("");
}

$("searchInput").addEventListener("input", renderRequests);
$("statusFilter").addEventListener("change", renderRequests);
$("proposalFilter").addEventListener("change", renderRequests);

/* =========================================
   07. ABRIR E FECHAR O FORMULÁRIO
========================================= */

const modal = $("requestModal");
const form = $("requestForm");
const formError = $("formError");

function openModal() {
    modal.classList.remove("hidden");
    document.body.style.overflow = "hidden";
    $("clientName").focus();
}

function closeModal() {
    modal.classList.add("hidden");
    document.body.style.overflow = "";
    formError.classList.add("hidden");
}

$("newRequestButton").addEventListener("click", function () {
    form.reset();
    $("requestId").value = "";
    $("modalTitle").textContent = "Nova solicitação";
    $("requestStatus").value = "Nova";
    $("proposalStatus").value = "Não elaborada";
    formError.classList.add("hidden");

    openModal();
});

$("closeModal").addEventListener("click", closeModal);
$("cancelModal").addEventListener("click", closeModal);

modal.addEventListener("click", function (event) {
    if (event.target === modal) {
        closeModal();
    }
});

document.addEventListener("keydown", function (event) {
    if (event.key === "Escape" && !modal.classList.contains("hidden")) {
        closeModal();
    }
});

/* =========================================
   08. EDITAR SOLICITAÇÃO
========================================= */

$("requestsTableBody").addEventListener("click", function (event) {
    const button = event.target.closest("[data-edit-request]");

    if (!button) return;

    const id = Number(button.dataset.editRequest);
    const item = data.requests.find(request => Number(request.id) === id);

    if (!item) return;

    form.reset();

    $("requestId").value = item.id;
    $("clientName").value = item.name;
    $("clientEmail").value = item.email;
    $("clientPhone").value = item.phone;
    $("sessionType").value = item.service;
    $("desiredDate").value = item.date;
    $("clientNotes").value = item.notes;
    $("requestStatus").value = item.status;
    $("proposalStatus").value = item.proposalStatus;
    $("proposalAmount").value = item.proposalAmount || "";
    $("proposalValidity").value = item.proposalValidity;
    $("proposalConditions").value = item.proposalConditions;

    $("modalTitle").textContent = "Editar solicitação";
    formError.classList.add("hidden");

    openModal();
});

/* =========================================
   09. CADASTRAR E SALVAR ALTERAÇÕES
========================================= */

form.addEventListener("submit", function (event) {
    event.preventDefault();
    formError.classList.add("hidden");

    const idValue = $("requestId").value;
    const name = $("clientName").value.trim();
    const email = $("clientEmail").value.trim();
    const phone = $("clientPhone").value.trim();
    const service = $("sessionType").value.trim();
    const date = $("desiredDate").value;
    const notes = $("clientNotes").value.trim();

    const status = $("requestStatus").value;
    const proposalStatus = $("proposalStatus").value;

    const rawAmount = $("proposalAmount").value;
    const proposalAmount = rawAmount === "" ? 0 : Number(rawAmount);

    if (!name || !service) {
        formError.textContent = "Preencha o nome e o tipo de ensaio.";
        formError.classList.remove("hidden");
        return;
    }

    if (
        !VALID_STATUSES.includes(status) ||
        !VALID_PROPOSAL_STATUSES.includes(proposalStatus)
    ) {
        formError.textContent = "Selecione um status válido.";
        formError.classList.remove("hidden");
        return;
    }

    if (!Number.isFinite(proposalAmount) || proposalAmount < 0) {
        formError.textContent = "Informe um valor válido para a proposta.";
        formError.classList.remove("hidden");
        return;
    }

    const existingIndex = idValue
        ? data.requests.findIndex(item => Number(item.id) === Number(idValue))
        : -1;

    const existing = existingIndex >= 0
        ? data.requests[existingIndex]
        : null;

    const request = {
        id: existing ? existing.id : Date.now(),
        name,
        email,
        phone,
        service,
        date,
        notes,
        status,
        proposalStatus,
        proposalAmount,
        proposalValidity: $("proposalValidity").value,
        proposalConditions: $("proposalConditions").value.trim()
    };

    if (existingIndex >= 0) {
        data.requests[existingIndex] = request;
    } else {
        data.requests.unshift(request);
    }

    if (!saveData()) {
        return;
    }

    renderAll();
    closeModal();
});

/* =========================================
   10. ATUALIZAR TODA A PÁGINA
========================================= */

function renderAll() {
    renderSummary();
    renderRequests();
}

renderAll();
