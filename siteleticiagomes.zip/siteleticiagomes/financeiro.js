
const DASHBOARD_KEY = "leticia_dashboard_v1";
const CLIENTS_KEY = "leticia_clients_v1";
const DELIVERIES_KEY = "leticia_deliveries_v1";

const $ = (id) => document.getElementById(id);

let transactions = loadTransactions();
let clients = loadArray(CLIENTS_KEY);
let deliveries = loadArray(DELIVERIES_KEY);

function loadDashboard() {
  try {
    const data = JSON.parse(localStorage.getItem(DASHBOARD_KEY) || "{}");
    return data && typeof data === "object" && !Array.isArray(data) ? data : {};
  } catch {
    return {};
  }
}

function loadTransactions() {
  const data = loadDashboard();
  return Array.isArray(data.finances) ? data.finances : [];
}

function loadArray(key) {
  try {
    const data = JSON.parse(localStorage.getItem(key) || "[]");
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

function saveTransactions() {
  try {
    const dashboard = loadDashboard();

    // Preserva as outras informações do painel administrativo.
    dashboard.requests = Array.isArray(dashboard.requests) ? dashboard.requests : [];
    dashboard.sessions = Array.isArray(dashboard.sessions) ? dashboard.sessions : [];
    dashboard.deliveries = Array.isArray(dashboard.deliveries) ? dashboard.deliveries : [];
    dashboard.tasks = Array.isArray(dashboard.tasks) ? dashboard.tasks : [];
    dashboard.finances = transactions;

    localStorage.setItem(DASHBOARD_KEY, JSON.stringify(dashboard));
    return true;
  } catch {
    alert("Não foi possível salvar os lançamentos. Verifique o espaço disponível no navegador.");
    return false;
  }
}

function createId() {
  return window.crypto?.randomUUID?.()
    || `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[char]);
}

function normalizeText(value) {
  return String(value || "").trim();
}

function money(value) {
  return Number(value || 0).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL"
  });
}

function formatDate(value) {
  if (!value) return "—";

  const parts = value.split("-");
  if (parts.length !== 3) return value;

  return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

function currentMonth() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}

function getEffectiveDate(item) {
  // Para o fluxo de caixa, utiliza a data real de pagamento/recebimento.
  // Se ela não estiver preenchida, utiliza a data do lançamento.
  return item.status === "Pago" && item.paidDate
    ? item.paidDate
    : item.date;
}

function getMonthTransactions() {
  const month = $("monthFilter").value;
  if (!month) return transactions;

  return transactions.filter((item) =>
    String(getEffectiveDate(item) || "").startsWith(month)
  );
}

function getClientName(clientId) {
  const client = clients.find((item) => String(item.id) === String(clientId));
  return client?.name || "";
}

function getDeliveryTitle(deliveryId) {
  const delivery = deliveries.find((item) => String(item.id) === String(deliveryId));
  return delivery?.title || "";
}

function renderClientOptions(selectedId = "") {
  $("transactionClient").innerHTML = `
    <option value="">Sem cliente associado</option>
    ${clients
      .slice()
      .sort((a, b) => String(a.name || "").localeCompare(String(b.name || ""), "pt-BR"))
      .map((client) => `
        <option value="${escapeHTML(client.id)}"
          ${String(client.id) === String(selectedId) ? "selected" : ""}>
          ${escapeHTML(client.name || "Cliente sem nome")}
        </option>
      `).join("")}
  `;
}

function renderDeliveryOptions(selectedId = "") {
  $("transactionDelivery").innerHTML = `
    <option value="">Sem trabalho associado</option>
    ${deliveries
      .slice()
      .sort((a, b) => String(a.title || "").localeCompare(String(b.title || ""), "pt-BR"))
      .map((delivery) => `
        <option value="${escapeHTML(delivery.id)}"
          ${String(delivery.id) === String(selectedId) ? "selected" : ""}>
          ${escapeHTML(delivery.title || "Trabalho sem nome")}
        </option>
      `).join("")}
  `;
}

function renderSummary() {
  const items = getMonthTransactions();

  const incomeReceived = items
    .filter((item) => item.type === "Receita" && item.status === "Pago")
    .reduce((sum, item) => sum + Number(item.amount || 0), 0);

  const expensesPaid = items
    .filter((item) => item.type === "Despesa" && item.status === "Pago")
    .reduce((sum, item) => sum + Number(item.amount || 0), 0);

  const toReceive = items
    .filter((item) => item.type === "Receita" && item.status === "Pendente")
    .reduce((sum, item) => sum + Number(item.amount || 0), 0);

  const toPay = items
    .filter((item) => item.type === "Despesa" && item.status === "Pendente")
    .reduce((sum, item) => sum + Number(item.amount || 0), 0);

  $("incomeTotal").textContent = money(incomeReceived);
  $("expenseTotal").textContent = money(expensesPaid);
  $("balanceTotal").textContent = money(incomeReceived - expensesPaid);
  $("pendingTotal").textContent = money(toReceive + toPay);

  $("balanceTotal").style.color =
    incomeReceived - expensesPaid < 0 ? "var(--vermelho)" : "var(--vinho)";

  $("pendingDescription").textContent =
    `${money(toReceive)} a receber · ${money(toPay)} a pagar`;

  $("receivedBreakdown").textContent = money(incomeReceived);
  $("toReceiveBreakdown").textContent = money(toReceive);
  $("paidBreakdown").textContent = money(expensesPaid);
  $("toPayBreakdown").textContent = money(toPay);

  $("incomeCount").textContent = `${items.filter((item) => item.type === "Receita").length} lançamento(s)`;
  $("expenseCount").textContent = `${items.filter((item) => item.type === "Despesa").length} lançamento(s)`;
}

function renderRow(item) {
  const clientName = getClientName(item.clientId);
  const deliveryTitle = getDeliveryTitle(item.deliveryId);

  const related = [clientName, deliveryTitle].filter(Boolean).join(" · ");

  const typeClass = item.type === "Receita" ? "type-income" : "type-expense";
  const amountClass = item.type === "Receita" ? "amount-income" : "amount-expense";
  const statusClass = item.status === "Pago" ? "payment-paid" : "payment-pending";

  const statusLabel = item.status === "Pago"
    ? (item.type === "Receita" ? "Recebido" : "Pago")
    : "Pendente";

  return `
    <tr>
      <td>
        <span class="transaction-name">${escapeHTML(item.description)}</span>
        ${item.notes
          ? `<span class="transaction-note">${escapeHTML(item.notes)}</span>`
          : ""}
      </td>

      <td class="transaction-date">${formatDate(item.date)}</td>
      <td>${escapeHTML(item.category || "Outros")}</td>
      <td>${escapeHTML(related || "—")}</td>
      <td><span class="type-label ${typeClass}">${escapeHTML(item.type)}</span></td>
      <td><span class="payment-pill ${statusClass}">${statusLabel}</span></td>
      <td class="amount-cell ${amountClass}">${money(item.amount)}</td>

      <td>
        <div class="row-actions">
          <button class="table-action" type="button"
            data-action="edit" data-id="${escapeHTML(item.id)}">Editar</button>
          <button class="table-action" type="button"
            data-action="delete" data-id="${escapeHTML(item.id)}">Excluir</button>
        </div>
      </td>
    </tr>
  `;
}

function renderTransactions() {
  const search = normalizeText($("searchTransaction").value)
    .toLocaleLowerCase("pt-BR");

  const type = $("typeFilter").value;
  const status = $("paymentFilter").value;

  const filtered = getMonthTransactions()
    .filter((item) => {
      const searchText = [
        item.description,
        item.category,
        item.notes,
        item.method,
        getClientName(item.clientId),
        getDeliveryTitle(item.deliveryId)
      ].join(" ").toLocaleLowerCase("pt-BR");

      if (search && !searchText.includes(search)) return false;
      if (type && item.type !== type) return false;
      if (status && item.status !== status) return false;

      return true;
    })
    .sort((a, b) =>
      String(getEffectiveDate(b) || "").localeCompare(String(getEffectiveDate(a) || ""))
    );

  $("transactionsTableBody").innerHTML = filtered.map(renderRow).join("");

  $("resultCount").textContent =
    `${filtered.length} ${filtered.length === 1 ? "lançamento" : "lançamentos"}`;

  $("emptyState").classList.toggle("visible", filtered.length === 0);
  $("transactionsTableBody").parentElement.style.display =
    filtered.length === 0 ? "none" : "table";

  $("emptyState").querySelector("h3").textContent =
    transactions.length === 0
      ? "Nenhum lançamento encontrado"
      : "Nenhum resultado encontrado";

  $("emptyState").querySelector("p").textContent =
    transactions.length === 0
      ? "Cadastre sua primeira receita ou despesa para acompanhar o caixa."
      : "Tente alterar a busca, o mês ou os filtros.";

  $("emptyNewBtn").style.display =
    transactions.length === 0 ? "inline-flex" : "none";

  // Soma dos lançamentos atualmente visíveis, considerando receitas positivas
  // e despesas negativas.
  const filteredBalance = filtered.reduce((sum, item) => {
    const amount = Number(item.amount || 0);
    return sum + (item.type === "Despesa" ? -amount : amount);
  }, 0);

  $("filteredTotal").textContent = money(filteredBalance);
}

function renderAll() {
  renderSummary();
  renderTransactions();
}

function openModal() {
  $("transactionModal").classList.add("open");
  $("transactionModal").setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
}

function closeModal() {
  $("transactionModal").classList.remove("open");
  $("transactionModal").setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}

function resetForm() {
  $("transactionForm").reset();
  $("transactionId").value = "";
  $("transactionDate").value = todayString();
  $("transactionStatus").value = "Pendente";
  $("transactionType").value = "Receita";
  $("formFeedback").textContent = "";

  renderClientOptions();
  renderDeliveryOptions();
}

function openNewTransaction() {
  resetForm();
  $("modalTitle").textContent = "Novo lançamento";
  openModal();
  $("transactionDescription").focus();
}

function openEditTransaction(id) {
  const item = transactions.find((transaction) => String(transaction.id) === String(id));
  if (!item) return;

  resetForm();

  $("transactionId").value = item.id;
  $("transactionType").value = item.type || "Receita";
  $("transactionStatus").value = item.status || "Pendente";
  $("transactionDescription").value = item.description || "";
  $("transactionAmount").value = item.amount ?? "";
  $("transactionDate").value = item.date || "";
  $("transactionDueDate").value = item.dueDate || "";
  $("transactionPaidDate").value = item.paidDate || "";
  $("transactionCategory").value = item.category || "Outros";
  $("transactionMethod").value = item.method || "";
  $("transactionNotes").value = item.notes || "";

  renderClientOptions(item.clientId || "");
  renderDeliveryOptions(item.deliveryId || "");

  $("modalTitle").textContent = "Editar lançamento";
  openModal();
}

function todayString() {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function handleSaveTransaction(event) {
  event.preventDefault();

  const id = $("transactionId").value;
  const existing = transactions.find((item) => String(item.id) === String(id));

  const type = $("transactionType").value;
  const status = $("transactionStatus").value;
  const description = normalizeText($("transactionDescription").value);
  const amount = Number($("transactionAmount").value);
  const date = $("transactionDate").value;
  const dueDate = $("transactionDueDate").value;
  let paidDate = $("transactionPaidDate").value;

  $("formFeedback").textContent = "";

  if (!["Receita", "Despesa"].includes(type)) {
    $("formFeedback").textContent = "Selecione receita ou despesa.";
    return;
  }

  if (!["Pago", "Pendente"].includes(status)) {
    $("formFeedback").textContent = "Selecione uma situação válida.";
    return;
  }

  if (!description || !date || !Number.isFinite(amount) || amount <= 0) {
    $("formFeedback").textContent =
      "Preencha a descrição, a data e um valor maior que zero.";
    return;
  }

  if (status === "Pago" && !paidDate) {
    paidDate = todayString();
  }

  if (status === "Pendente") {
    paidDate = "";
  }

  const now = new Date().toISOString();

  const item = {
    id: existing?.id || createId(),
    type,
    status,
    description,
    amount: Math.round(amount * 100) / 100,
    date,
    dueDate,
    paidDate,
    category: $("transactionCategory").value,
    method: $("transactionMethod").value,
    clientId: $("transactionClient").value,
    deliveryId: $("transactionDelivery").value,
    notes: normalizeText($("transactionNotes").value),
    createdAt: existing?.createdAt || now,
    updatedAt: now
  };

  const previousTransactions = [...transactions];

  if (existing) {
    transactions = transactions.map((transaction) =>
      String(transaction.id) === String(existing.id) ? item : transaction
    );
  } else {
    transactions.push(item);
  }

  if (!saveTransactions()) {
    transactions = previousTransactions;
    return;
  }

  closeModal();
  renderAll();
}

function deleteTransaction(id) {
  const item = transactions.find((transaction) => String(transaction.id) === String(id));
  if (!item) return;

  const confirmed = window.confirm(
    `Deseja excluir o lançamento "${item.description}" no valor de ${money(item.amount)}?`
  );

  if (!confirmed) return;

  const previousTransactions = [...transactions];
  transactions = transactions.filter((transaction) => String(transaction.id) !== String(id));

  if (!saveTransactions()) {
    transactions = previousTransactions;
    return;
  }

  renderAll();
}

function exportCSV() {
  const items = getMonthTransactions();
  const headers = [
    "Descrição",
    "Tipo",
    "Situação",
    "Valor",
    "Data do lançamento",
    "Vencimento",
    "Data do pagamento",
    "Categoria",
    "Forma de pagamento",
    "Cliente",
    "Ensaio",
    "Observações"
  ];

  const rows = items.map((item) => [
    item.description,
    item.type,
    item.status,
    Number(item.amount || 0).toFixed(2).replace(".", ","),
    formatDate(item.date),
    formatDate(item.dueDate),
    formatDate(item.paidDate),
    item.category,
    item.method,
    getClientName(item.clientId),
    getDeliveryTitle(item.deliveryId),
    item.notes
  ]);

  // Escapa aspas e mantém cada campo em uma única célula CSV.
  const csvCell = (value) =>
    `"${String(value ?? "").replace(/"/g, '""')}"`;

  const csv = [
    headers.map(csvCell).join(";"),
    ...rows.map((row) => row.map(csvCell).join(";"))
  ].join("\r\n");

  const blob = new Blob(["\uFEFF", csv], {
    type: "text/csv;charset=utf-8;"
  });

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = `relatorio-financeiro-${$("monthFilter").value || "completo"}.csv`;

  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function refreshRelatedData() {
  clients = loadArray(CLIENTS_KEY);
  deliveries = loadArray(DELIVERIES_KEY);

  renderClientOptions($("transactionClient").value);
  renderDeliveryOptions($("transactionDelivery").value);
  renderAll();
}

function setupEvents() {
  $("newTransactionBtn").addEventListener("click", openNewTransaction);
  $("emptyNewBtn").addEventListener("click", openNewTransaction);

  $("transactionForm").addEventListener("submit", handleSaveTransaction);

  $("monthFilter").addEventListener("change", renderAll);
  $("currentMonthBtn").addEventListener("click", () => {
    $("monthFilter").value = currentMonth();
    renderAll();
  });

  $("searchTransaction").addEventListener("input", renderTransactions);
  $("typeFilter").addEventListener("change", renderTransactions);
  $("paymentFilter").addEventListener("change", renderTransactions);

  $("exportCsvBtn").addEventListener("click", exportCSV);

  $("transactionsTableBody").addEventListener("click", (event) => {
    const button = event.target.closest("[data-action]");
    if (!button) return;

    if (button.dataset.action === "edit") {
      openEditTransaction(button.dataset.id);
    } else if (button.dataset.action === "delete") {
      deleteTransaction(button.dataset.id);
    }
  });

  document.querySelectorAll("[data-close='transactionModal']").forEach((button) => {
    button.addEventListener("click", closeModal);
  });

  $("transactionModal").addEventListener("click", (event) => {
    if (event.target === $("transactionModal")) closeModal();
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeModal();
  });

  $("mobileMenu").addEventListener("click", () => {
    $("sidebar").classList.toggle("open");
  });

  $("logoutBtn").addEventListener("click", () => {
    window.location.href = "login.html";
  });

  window.addEventListener("storage", (event) => {
    if (event.key === DASHBOARD_KEY) {
      transactions = loadTransactions();
      renderAll();
    }

    if (event.key === CLIENTS_KEY || event.key === DELIVERIES_KEY) {
      refreshRelatedData();
    }
  });
}

function init() {
  $("monthFilter").value = currentMonth();

  renderClientOptions();
  renderDeliveryOptions();
  setupEvents();
  renderAll();
}

init();
