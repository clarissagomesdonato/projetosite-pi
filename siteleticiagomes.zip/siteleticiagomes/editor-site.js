
const DRAFT_KEY = "leticia_site_draft_v1";
const PUBLISHED_KEY = "leticia_site_published_v1";

const $ = (id) => document.getElementById(id);

const CURRENT_SITE = {
  homeEyebrow: "Fotografia Criativa - São Paulo",
  homeQuote: "Acredito que cada pessoa carrega uma linda história extraordinária. Meu convite para você é eternizar essa história que faz o coração sorrir",
  homeButton: "Orçamento",
  homeButtonLink: "#orcamento",
  homePhoto: "foto1.jpe",
  portfolioHeading: "Histórias que merecem ser lembradas",
  portfolioDescription: "Um olhar sensível para pessoas, sentimentos e momentos únicos.",
  aboutHeadingHome: "Prazer, sou a Letícia",

  aboutHeading: "Prazer, sou a Letícia",
  aboutSubtitle: "Sobre a fotógrafa",
  aboutBiography: `Toda história começa com um olhar. A minha começou quando eu tinha apenas 10 anos. Eu estava em uma festa infantil quando conheci um fotógrafo que despertou minha curiosidade por sua câmera e pelo que era capaz de registrar através dela. Ele me deixou experimentar um pouquinho daquele universo e, naquele momento, nasceu em mim o sonho de me tornar fotógrafa.

Minha jornada começou registrando momentos na igreja, sempre com vontade de aprender, aprimorar meu olhar e evoluir profissionalmente. Com o tempo, passei a compartilhar meu trabalho nas redes sociais e a participar de trabalhos voluntários, encontrando novas oportunidades para praticar, crescer e transformar minha paixão em profissão.

Além da fotografia, também gosto muito de ler, principalmente romances. Depois de visitar minha primeira Bienal do Livro, esse carinho pela leitura ganhou ainda mais espaço. Afinal, seja por meio de uma fotografia, de um filme ou das páginas de um romance, acredito que as histórias têm o poder de nos fazer sentir e enxergar o mundo de novas maneiras.

Hoje, quero que cada pessoa que passe pelas minhas lentes se sinta acolhida, confortável e bonita sendo exatamente quem é. Para mim, uma fotografia vai muito além de uma imagem: ela carrega sentimentos, revela detalhes e conta histórias que merecem ser lembradas.

E meus sonhos não param por aqui! Quero continuar crescendo na fotografia, explorando o universo dos vídeos e, no futuro, realizar outro grande sonho: me tornar diretora de cinema.

Enquanto construo esse caminho, quero contar histórias através do meu olhar e criar lembranças que façam você sentir tudo outra vez, mesmo anos depois.`,
  aboutPhoto: "fotole3.jpe",

  processHeading: "Como o nosso trabalho irá funcionar?",
  processDescription: "Cada detalhe importa quando o objetivo é transformar momentos especiais em lembranças para a vida toda.",
  ctaEyebrow: "VAMOS CRIAR MEMÓRIAS?",
  ctaHeading: "Sua história também merece ser contada.",
  ctaDescription: "Vamos conversar sobre o ensaio que você imagina e transformar esse momento em lembranças para guardar com carinho.",
  contactEmail: "",
  contactInstagram: "https://www.instagram.com/",
  footerDescription: "Fotografias que guardam histórias, sentimentos e momentos especiais.",

  portfolio: Array.from({ length: 16 }, (_, index) => ({
    id: `foto-${index + 1}`,
    src: `foto${index + 1}.jpe`,
    alt: `Fotografia de ensaio, imagem ${index + 1}`,
    caption: "",
    category: "Ensaio fotográfico"
  }))
};

let draft = null;
let published = null;
let activeSection = "home";
let pendingUploads = {};
let originalDraftSnapshot = "";

function deepCopy(value) {
  return JSON.parse(JSON.stringify(value));
}

function readJSON(key) {
  try {
    const value = JSON.parse(localStorage.getItem(key) || "null");
    return value && typeof value === "object" ? value : null;
  } catch {
    return null;
  }
}

function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[char]);
}

function showFeedback(message, isError = false) {
  const feedback = $("editorFeedback");
  feedback.textContent = message;
  feedback.classList.toggle("error", isError);
}

function setStatus(message, saved = false) {
  $("publicationStatus").textContent = message;
  $("lastSaved").textContent = saved
    ? `Salvo em ${new Date().toLocaleString("pt-BR")}`
    : "Existem alterações que ainda não foram salvas.";

  document.querySelector(".status-dot").classList.toggle("saved", saved);
}

function getFormData() {
  const data = {};

  Object.keys(CURRENT_SITE).forEach((key) => {
    if (key !== "portfolio") {
      data[key] = $(key)?.value ?? draft[key] ?? CURRENT_SITE[key];
    }
  });

  data.portfolio = deepCopy(draft.portfolio);
  return data;
}

function fillForm(data) {
  Object.keys(CURRENT_SITE).forEach((key) => {
    if (key === "portfolio") return;
    if ($(key)) $(key).value = data[key] ?? CURRENT_SITE[key];
  });

  renderPortfolio();
  updateImagePreview("homePhoto", "homePhotoPreview");
  updateImagePreview("aboutPhoto", "aboutPhotoPreview");
}

function currentSnapshot() {
  return JSON.stringify(getFormData());
}

function markDirty() {
  setStatus("Alterações não salvas", false);
  showFeedback("");
}

function activateSection(sectionName) {
  activeSection = sectionName;

  document.querySelectorAll(".editor-tab").forEach((tab) => {
    tab.classList.toggle("active", tab.dataset.section === sectionName);
  });

  document.querySelectorAll(".editor-section").forEach((section) => {
    section.classList.toggle("active", section.dataset.panel === sectionName);
  });
}

function loadSiteData() {
  published = readJSON(PUBLISHED_KEY) || deepCopy(CURRENT_SITE);
  draft = readJSON(DRAFT_KEY) || deepCopy(published);

  // Garante os campos que possam faltar em uma versão antiga.
  draft = { ...deepCopy(CURRENT_SITE), ...draft };
  published = { ...deepCopy(CURRENT_SITE), ...published };

  if (!Array.isArray(draft.portfolio)) {
    draft.portfolio = deepCopy(CURRENT_SITE.portfolio);
  }

  if (!Array.isArray(published.portfolio)) {
    published.portfolio = deepCopy(CURRENT_SITE.portfolio);
  }

  fillForm(draft);
  originalDraftSnapshot = currentSnapshot();

  const wasPublished = Boolean(readJSON(PUBLISHED_KEY));
  setStatus(
    wasPublished ? "Versão publicada carregada" : "Conteúdo inicial carregado",
    true
  );
}

function resolveImageSource(src) {
  const value = String(src || "").trim();

  if (/^(data:image\/|blob:)/i.test(value)) return value;

  // Permite imagens da pasta do projeto e URLs HTTP(S).
  // Não permite caminhos executáveis ou esquemas inesperados.
  if (/^(https?:\/\/|\/)/i.test(value)) return value;
  if (/^[a-zA-Z0-9_\-./ ]+\.(jpe?g|png|webp|gif|avif)$/i.test(value)) {
    return value;
  }

  return "";
}

function updateImagePreview(inputId, previewId) {
  const inputValue = $(inputId).value.trim();
  const src = resolveImageSource(inputValue);
  const preview = $(previewId);

  if (!src) {
    preview.classList.remove("visible");
    preview.innerHTML = "";
    return;
  }

  preview.innerHTML = `<img src="${escapeHTML(src)}" alt="Prévia da imagem selecionada">`;
  preview.classList.add("visible");

  const img = preview.querySelector("img");
  img.addEventListener("error", () => {
    preview.classList.remove("visible");
    preview.innerHTML = "";
  }, { once: true });
}

function renderPortfolio() {
  const list = $("portfolioEditorList");

  $("photoCount").textContent =
    `${draft.portfolio.length} ${draft.portfolio.length === 1 ? "fotografia" : "fotografias"}`;

  list.innerHTML = draft.portfolio.map((photo, index) => {
    const src = resolveImageSource(photo.src);

    return `
      <article class="photo-card" data-photo-id="${escapeHTML(photo.id)}">
        <div class="photo-card-image">
          ${src
            ? `<img src="${escapeHTML(src)}" alt="${escapeHTML(photo.alt || "")}">`
            : `<span class="field-help">Imagem indisponível</span>`}
          <span class="photo-card-number">${String(index + 1).padStart(2, "0")}</span>
        </div>

        <div class="photo-card-fields">
          <label>
            Arquivo / caminho
            <input data-photo-field="src" value="${escapeHTML(photo.src)}"
              maxlength="1000" placeholder="Ex.: foto1.jpe">
          </label>

          <label>
            Legenda
            <input data-photo-field="caption" value="${escapeHTML(photo.caption || "")}"
              maxlength="200" placeholder="Legenda da fotografia">
          </label>

          <label>
            Categoria
            <select data-photo-field="category">
              ${["Ensaio fotográfico", "Retrato", "Ensaio feminino",
                "Casamento e eventos", "Família", "Infantil", "Editorial", "Outros"]
                .map((category) => `
                  <option value="${escapeHTML(category)}"
                    ${photo.category === category ? "selected" : ""}>
                    ${escapeHTML(category)}
                  </option>
                `).join("")}
            </select>
          </label>

          <label>
            Texto alternativo da imagem
            <input data-photo-field="alt" value="${escapeHTML(photo.alt || "")}"
              maxlength="250" placeholder="Descrição da fotografia">
          </label>

          <label>
            Substituir arquivo
            <input type="file" accept="image/*" data-photo-upload="${escapeHTML(photo.id)}">
          </label>

          <div class="photo-card-actions">
            <button type="button" data-photo-action="up"
              data-id="${escapeHTML(photo.id)}" ${index === 0 ? "disabled" : ""}>
              ↑
            </button>
            <button type="button" data-photo-action="down"
              data-id="${escapeHTML(photo.id)}"
              ${index === draft.portfolio.length - 1 ? "disabled" : ""}>
              ↓
            </button>
            <button type="button" data-photo-action="remove"
              data-id="${escapeHTML(photo.id)}" class="remove-photo">
              Remover
            </button>
          </div>
        </div>
      </article>
    `;
  }).join("");
}

function fileToDataURL(file) {
  return new Promise((resolve, reject) => {
    if (!file || !file.type.startsWith("image/")) {
      reject(new Error("Selecione um arquivo de imagem válido."));
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      reject(new Error("Para esta versão do protótipo, use imagens de até 2 MB."));
      return;
    }

    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Não foi possível ler a imagem."));
    reader.readAsDataURL(file);
  });
}

async function handleSingleImageUpload(event, fieldId, previewId) {
  const file = event.target.files?.[0];
  if (!file) return;

  try {
    const dataURL = await fileToDataURL(file);
    pendingUploads[fieldId] = dataURL;
    $(fieldId).value = dataURL;
    updateImagePreview(fieldId, previewId);
    markDirty();
    showFeedback("Imagem carregada na prévia. Salve o rascunho para guardar a alteração.");
  } catch (error) {
    showFeedback(error.message, true);
  }

  event.target.value = "";
}

async function addPortfolioFiles(files) {
  const validFiles = Array.from(files || []).filter((file) =>
    file.type.startsWith("image/")
  );

  if (!validFiles.length) return;

  for (const file of validFiles) {
    try {
      const src = await fileToDataURL(file);

      draft.portfolio.push({
        id: `photo-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        src,
        alt: file.name.replace(/\.[^.]+$/, "").replace(/[_-]/g, " "),
        caption: "",
        category: "Ensaio fotográfico"
      });
    } catch (error) {
      showFeedback(error.message, true);
    }
  }

  renderPortfolio();
  markDirty();
  showFeedback("Fotografias adicionadas ao rascunho. Salve para guardar as alterações.");
}

function movePhoto(id, direction) {
  const index = draft.portfolio.findIndex((photo) => photo.id === id);
  const newIndex = index + direction;

  if (index < 0 || newIndex < 0 || newIndex >= draft.portfolio.length) return;

  [draft.portfolio[index], draft.portfolio[newIndex]] =
    [draft.portfolio[newIndex], draft.portfolio[index]];

  renderPortfolio();
  markDirty();
}

function removePhoto(id) {
  const photo = draft.portfolio.find((item) => item.id === id);
  if (!photo) return;

  if (!window.confirm("Remover esta fotografia do portfólio em edição?")) return;

  draft.portfolio = draft.portfolio.filter((item) => item.id !== id);
  renderPortfolio();
  markDirty();
}

function handlePortfolioInput(event) {
  const card = event.target.closest("[data-photo-id]");
  if (!card) return;

  const id = card.dataset.photoId;
  const photo = draft.portfolio.find((item) => item.id === id);
  if (!photo) return;

  const field = event.target.dataset.photoField;
  if (!field) return;

  photo[field] = event.target.value;
  markDirty();

  if (field === "src") {
    const imageContainer = card.querySelector(".photo-card-image");
    const src = resolveImageSource(photo.src);

    imageContainer.querySelector("img")?.remove();

    if (src) {
      const img = document.createElement("img");
      img.src = src;
      img.alt = photo.alt || "";
      img.addEventListener("error", () => img.remove(), { once: true });
      imageContainer.prepend(img);
    }
  }
}

async function handlePortfolioUpload(event) {
  const input = event.target;
  const id = input.dataset.photoUpload;
  const file = input.files?.[0];

  if (!id || !file) return;

  try {
    const dataURL = await fileToDataURL(file);
    const photo = draft.portfolio.find((item) => item.id === id);
    if (!photo) return;

    photo.src = dataURL;
    renderPortfolio();
    markDirty();
    showFeedback("Imagem substituída no rascunho. Salve para guardar a alteração.");
  } catch (error) {
    showFeedback(error.message, true);
  }

  // Não perder o arquivo por causa do redesenho da lista.
  input.value = "";
}

function saveDraft() {
  draft = getFormData();

  try {
    localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
    originalDraftSnapshot = currentSnapshot();
    setStatus("Rascunho salvo neste navegador", true);
    showFeedback("Rascunho salvo! A versão publicada não foi alterada.");
    return true;
  } catch {
    showFeedback(
      "Não foi possível salvar. As imagens podem ultrapassar o espaço disponível no navegador. Use arquivos menores.",
      true
    );
    return false;
  }
}

function openPublishModal() {
  draft = getFormData();
  $("publishModal").classList.add("open");
  $("publishModal").setAttribute("aria-hidden", "false");
}

function closePublishModal() {
  $("publishModal").classList.remove("open");
  $("publishModal").setAttribute("aria-hidden", "true");
}

function publishSite() {
  const data = getFormData();

  const invalidImage = [
    data.homePhoto,
    data.aboutPhoto,
    ...data.portfolio.map((photo) => photo.src)
  ].some((src) => !resolveImageSource(src));

  if (invalidImage) {
    closePublishModal();
    showFeedback(
      "Revise os caminhos das imagens: há pelo menos uma imagem sem um caminho válido.",
      true
    );
    return;
  }

  try {
    localStorage.setItem(PUBLISHED_KEY, JSON.stringify(data));
    localStorage.setItem(DRAFT_KEY, JSON.stringify(data));

    published = deepCopy(data);
    draft = deepCopy(data);
    originalDraftSnapshot = currentSnapshot();

    closePublishModal();
    setStatus("Versão publicada neste navegador", true);
    showFeedback(
      "Versão publicada localmente! Para refletir as mudanças no site público, conecte as páginas públicas ao arquivo de integração abaixo."
    );
  } catch {
    closePublishModal();
    showFeedback(
      "Não foi possível publicar. Reduza o tamanho das imagens ou use caminhos de arquivos já existentes.",
      true
    );
  }
}

function discardDraft() {
  if (!window.confirm("Descartar as alterações não salvas e recuperar o último rascunho?")) {
    return;
  }

  draft = readJSON(DRAFT_KEY) || deepCopy(published || CURRENT_SITE);
  draft = { ...deepCopy(CURRENT_SITE), ...draft };
  fillForm(draft);
  originalDraftSnapshot = currentSnapshot();

  setStatus("Rascunho recuperado", true);
  showFeedback("As alterações não salvas foram descartadas.");
}

function refreshPreview() {
  const iframe = $("currentSitePreview");
  iframe.src = `paginainicio.html?t=${Date.now()}`;
}

function setupEvents() {
  document.querySelectorAll(".editor-tab").forEach((tab) => {
    tab.addEventListener("click", () => activateSection(tab.dataset.section));
  });

  $("editorForm").addEventListener("input", (event) => {
    if (event.target.matches("[data-photo-field]")) return;

    markDirty();

    if (event.target.id === "homePhoto") {
      updateImagePreview("homePhoto", "homePhotoPreview");
    }

    if (event.target.id === "aboutPhoto") {
      updateImagePreview("aboutPhoto", "aboutPhotoPreview");
    }
  });

  $("homePhotoUpload").addEventListener("change", (event) =>
    handleSingleImageUpload(event, "homePhoto", "homePhotoPreview")
  );

  $("aboutPhotoUpload").addEventListener("change", (event) =>
    handleSingleImageUpload(event, "aboutPhoto", "aboutPhotoPreview")
  );

  $("addPhotoBtn").addEventListener("click", () => $("portfolioPhotoUpload").click());

  $("portfolioPhotoUpload").addEventListener("change", async (event) => {
    await addPortfolioFiles(event.target.files);
    event.target.value = "";
  });

  $("portfolioEditorList").addEventListener("input", handlePortfolioInput);

  $("portfolioEditorList").addEventListener("change", (event) => {
    if (event.target.matches("[data-photo-upload]")) {
      handlePortfolioUpload(event);
    } else if (event.target.matches("[data-photo-field]")) {
      handlePortfolioInput(event);
    }
  });

  $("portfolioEditorList").addEventListener("click", (event) => {
    const button = event.target.closest("[data-photo-action]");
    if (!button) return;

    const id = button.dataset.id;
    const action = button.dataset.photoAction;

    if (action === "up") movePhoto(id, -1);
    if (action === "down") movePhoto(id, 1);
    if (action === "remove") removePhoto(id);
  });

  $("saveDraftBtn").addEventListener("click", saveDraft);
  $("resetDraftBtn").addEventListener("click", discardDraft);
  $("publishBtn").addEventListener("click", openPublishModal);
  $("confirmPublishBtn").addEventListener("click", publishSite);
  $("refreshPreviewBtn").addEventListener("click", refreshPreview);

  document.querySelectorAll("[data-close='publishModal']").forEach((button) => {
    button.addEventListener("click", closePublishModal);
  });

  $("publishModal").addEventListener("click", (event) => {
    if (event.target === $("publishModal")) closePublishModal();
  });

  $("mobileMenu").addEventListener("click", () => {
    $("sidebar").classList.toggle("open");
  });

  $("logoutBtn").addEventListener("click", () => {
    window.location.href = "login.html";
  });

  window.addEventListener("beforeunload", (event) => {
    if (currentSnapshot() !== originalDraftSnapshot) {
      event.preventDefault();
      event.returnValue = "";
    }
  });
}

function init() {
  loadSiteData();
  setupEvents();
}

init();
