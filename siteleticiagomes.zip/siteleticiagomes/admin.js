
/* ========================================
   1. CONFIGURAÇÕES E ARMAZENAMENTO
======================================== */

const STORAGE_KEY = "leticia_dashboard_v1";

const $ = (id) => document.getElementById(id);

function dateOffset(days) {
    const date = new Date();
    date.setDate(date.getDate() + days);

    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");

    return `${year}-${month}-${day}`;
}

function createDemoData() {
    return {
        requests: [
            {
                id: 1,
                name: "Mariana Oliveira",
                service: "Ensaio individual",
                date: dateOffset(1),
                status: "Nova"
            },
            {
                id: 2,
                name: "Isabela Santos",
                service: "Ensaio de aniversário",
                date: dateOffset(2),
                status: "Nova"
            },
            {
                id: 3,
                name: "Camila Ferreira",
                service: "Ensaio profissional",
                date: dateOffset(4),
                status: "Nova"
            }
        ],

        sessions: [
            {
                id: 4,
                name: "Ana Carolina",
                service: "Ensaio externo",
                date: dateOffset(1),
                time: "10:00",
                status: "Agendado"
            },
            {
                id: 5,
                name: "Beatriz Lima",
                service: "Ensaio individual",
                date: dateOffset(3),
                time: "14:30",
                status: "Agendado"
            },
            {
                id: 6,
                name: "Laura Martins",
                service: "Ensaio profissional",
                date: dateOffset(6),
                time: "09:00",
                status: "Agendado"
            }
        ],

        deliveries: [
            {
                id: 7,
                name: "Ensaio de Júlia",
                service: "Edição e tratamento",
                dueDate: dateOffset(2),
                status: "Pendente"
            },
            {
                id: 8,
                name: "Ensaio de Fernanda",
                service: "Seleção de fotografias",
                dueDate: dateOffset(4),
                status: "Em andamento"
            },
            {
                id: 9,
                name: "Ensaio de Gabriela",
                service: "Galeria final",
                dueDate: dateOffset(7),
                status: "Pendente"
            }
        ],

        tasks: [
            { id: 10, title: "Organizar os arquivos dos ensaios", done: false },
            { id: 11, title: "Revisar as fotografias selecionadas", done: false },
            { id: 12, title: "Atualizar o portfólio do site", done: true }
        ],

        finances: [
            { id: 13, description: "Ensaio individual", type: "receita", status: "recebido", amount: 450 },
            { id: 14, description: "Ensaio profissional", type: "receita", status: "pendente", amount: 600 },
            { id: 15, description: "Impressões fotográficas", type: "despesa", status: "pago", amount: 80 }
        ]
    };
}

function loadData() {
    try {
        const saved = localStorage.getItem(STORAGE_KEY);

        if (!saved) {
            const initialData = createDemoData();
            saveData(initialData);
            return initialData;
        }

        const parsed = JSON.parse(saved);

        const valid =
            parsed &&
            Array.isArray(parsed.requests) &&
            Array.isArray(parsed.sessions) &&
            Array.isArray(parsed.deliveries) &&
            Array.isArray(parsed.tasks) &&
            Array.isArray(parsed.finances);

        if (!valid) {
            throw new Error("Dados salvos inválidos.");
        }

        return parsed;

    } catch (error) {
        console.error("Não foi possível carregar os dados:", error);

        alert(
            "Não foi possível ler os dados salvos. " +
            "Verifique o armazenamento deste navegador."
        );

        return createDemoData();
    }
}

function saveData(data) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

let data = loadData();

/* ========================================
   2. FUNÇÕES AUXILIARES
======================================== */

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, (character) => {
        const entities = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        };

        return entities[character];
    });
}

function formatCurrency(value) {
    return Number(value || 0).toLocaleString("pt-BR", {
        style: "currency",
        currency: "BRL"
    });
}

function formatDate(dateString) {
    if (!dateString) return "Sem data";

    const parts = dateString.split("-").map(Number);
    const date = new Date(parts[0], parts[1] - 1, parts[2]);

    return date.toLocaleDateString("pt-BR", {
        day: "2-digit",
        month: "short"
    }).replace(".", "");
}

function todayString() {
    return dateOffset(0);
}

function isUpcoming(dateString) {
    return dateString >= todayString();
}

function statusClass(status) {
    const normalized = String(status || "").toLowerCase();

    if (normalized.includes("recebido") ||
        normalized.includes("conclu")) {
        return "done";
    }

    if (normalized.includes("agendado")) {
        return "scheduled";
    }

    return "pending";
}

function showEmpty(containerId, message) {
    $(containerId).innerHTML = `
        <div class="empty-state">${escapeHTML(message)}</div>
    `;
}

/* ========================================
   3. DATA ATUAL E RODAPÉ
======================================== */

function renderDate() {
    const now = new Date();

    $("currentDate").textContent = now.toLocaleDateString("pt-BR", {
        weekday: "long",
        day: "numeric",
        month: "long",
        year: "numeric"
    });

    $("year").textContent = now.getFullYear();
}

/* ========================================
   4. INDICADORES DO DASHBOARD
======================================== */

function renderStats() {
    const newRequests = data.requests.filter(
        item => item.status.toLowerCase() === "nova"
    );

    const upcomingSessions = data.sessions.filter(
        item => isUpcoming(item.date) &&
                item.status.toLowerCase() !== "cancelado"
    );

    const pendingDeliveries = data.deliveries.filter(
        item => !["concluída", "concluida", "entregue"].includes(
            item.status.toLowerCase()
        )
    );

    const received = data.finances
        .filter(item =>
            item.type === "receita" &&
            item.status === "recebido"
        )
        .reduce((total, item) => total + Number(item.amount || 0), 0);

    $("newRequests").textContent = newRequests.length;
    $("upcomingSessions").textContent = upcomingSessions.length;
    $("pendingDeliveries").textContent = pendingDeliveries.length;
    $("totalRevenue").textContent = formatCurrency(received);
}

/* ========================================
   5. NOVAS SOLICITAÇÕES
======================================== */

function renderRequests() {
    const requests = data.requests
        .filter(item => item.status.toLowerCase() === "nova")
        .slice()
        .sort((a, b) => a.date.localeCompare(b.date))
        .slice(0, 4);

    if (requests.length === 0) {
        showEmpty("requestsList", "Nenhuma nova solicitação por enquanto.");
        return;
    }

    $("requestsList").innerHTML = requests.map(item => `
        <div class="data-row">
            <div class="row-avatar">
                ${escapeHTML(item.name.trim().charAt(0).toUpperCase())}
            </div>

            <div class="row-info">
                <strong>${escapeHTML(item.name)}</strong>
                <small>${escapeHTML(item.service)}</small>
            </div>

            <div class="row-meta">
                <span class="status">Nova</span>
                <small>${formatDate(item.date)}</small>
            </div>
        </div>
    `).join("");
}

/* ========================================
   6. PRÓXIMOS ENSAIOS
======================================== */

function renderSessions() {
    const sessions = data.sessions
        .filter(item =>
            isUpcoming(item.date) &&
            item.status.toLowerCase() !== "cancelado"
        )
        .slice()
        .sort((a, b) =>
            a.date.localeCompare(b.date) ||
            (a.time || "").localeCompare(b.time || "")
        )
        .slice(0, 4);

    if (sessions.length === 0) {
        showEmpty("sessionsList", "Nenhum ensaio agendado.");
        return;
    }

    $("sessionsList").innerHTML = sessions.map(item => `
        <div class="data-row">
            <div class="row-avatar peach">▦</div>

            <div class="row-info">
                <strong>${escapeHTML(item.name)}</strong>
                <small>${escapeHTML(item.service)}</small>
            </div>

            <div class="row-meta">
                <span class="status scheduled">
                    ${escapeHTML(item.status)}
                </span>
                <small>${formatDate(item.date)} · ${escapeHTML(item.time || "--:--")}</small>
            </div>
        </div>
    `).join("");
}

/* ========================================
   7. ENTREGAS PENDENTES
======================================== */

function renderDeliveries() {
    const deliveries = data.deliveries
        .filter(item =>
            !["concluída", "concluida", "entregue"].includes(
                item.status.toLowerCase()
            )
        )
        .slice()
        .sort((a, b) => a.dueDate.localeCompare(b.dueDate))
        .slice(0, 4);

    if (deliveries.length === 0) {
        showEmpty("deliveriesList", "Todas as entregas estão finalizadas!");
        return;
    }

    $("deliveriesList").innerHTML = deliveries.map(item => `
        <div class="data-row">
            <div class="row-avatar green">▧</div>

            <div class="row-info">
                <strong>${escapeHTML(item.name)}</strong>
                <small>${escapeHTML(item.service)}</small>
            </div>

            <div class="row-meta">
                <span class="status ${statusClass(item.status)}">
                    ${escapeHTML(item.status)}
                </span>
                <small>Prazo: ${formatDate(item.dueDate)}</small>
            </div>
        </div>
    `).join("");
}

/* ========================================
   8. TAREFAS
======================================== */

function renderTasks() {
    const pendingCount = data.tasks.filter(task => !task.done).length;

    $("taskCounter").textContent =
        `${pendingCount} ${pendingCount === 1 ? "pendente" : "pendentes"}`;

    if (data.tasks.length === 0) {
        showEmpty("tasksList", "Suas tarefas aparecerão aqui.");
        return;
    }

    $("tasksList").innerHTML = data.tasks.map(task => `
        <div class="task-item ${task.done ? "completed" : ""}">
            <input
                type="checkbox"
                data-task-id="${Number(task.id)}"
                aria-label="Concluir ${escapeHTML(task.title)}"
                ${task.done ? "checked" : ""}
            >

            <span>${escapeHTML(task.title)}</span>

            <button
                type="button"
                class="delete-task"
                data-delete-task="${Number(task.id)}"
                aria-label="Excluir tarefa"
            >×</button>
        </div>
    `).join("");
}

$("taskForm").addEventListener("submit", function (event) {
    event.preventDefault();

    const input = $("taskInput");
    const title = input.value.trim();

    if (!title) return;

    data.tasks.unshift({
        id: Date.now(),
        title: title,
        done: false
    });

    saveData(data);
    renderTasks();
    input.value = "";
    input.focus();
});

$("tasksList").addEventListener("change", function (event) {
    const id = Number(event.target.dataset.taskId);

    if (!id) return;

    const task = data.tasks.find(item => item.id === id);

    if (!task) return;

    task.done = event.target.checked;

    saveData(data);
    renderTasks();
});

$("tasksList").addEventListener("click", function (event) {
    const button = event.target.closest("[data-delete-task]");

    if (!button) return;

    const id = Number(button.dataset.deleteTask);

    data.tasks = data.tasks.filter(task => task.id !== id);

    saveData(data);
    renderTasks();
});

/* ========================================
   9. VISÃO FINANCEIRA
======================================== */

function renderFinance() {
    const received = data.finances
        .filter(item =>
            item.type === "receita" &&
            item.status === "recebido"
        )
        .reduce((sum, item) => sum + Number(item.amount || 0), 0);

    const pending = data.finances
        .filter(item =>
            item.type === "receita" &&
            item.status === "pendente"
        )
        .reduce((sum, item) => sum + Number(item.amount || 0), 0);

    const expenses = data.finances
        .filter(item =>
            item.type === "despesa" &&
            item.status === "pago"
        )
        .reduce((sum, item) => sum + Number(item.amount || 0), 0);

    const balance = received - expenses;

    $("financeReceived").textContent = formatCurrency(received);
    $("financePending").textContent = formatCurrency(pending);
    $("financeExpenses").textContent = formatCurrency(expenses);
    $("financeBalance").textContent = formatCurrency(balance);
}

/* ========================================
   10. ATUALIZAÇÃO GERAL
======================================== */

function renderDashboard() {
    renderDate();
    renderStats();
    renderRequests();
    renderSessions();
    renderDeliveries();
    renderTasks();
    renderFinance();
}

/* ========================================
   11. RESTAURAR DADOS DE DEMONSTRAÇÃO
======================================== */

$("resetDemo").addEventListener("click", function () {
    const confirmed = confirm(
        "Deseja restaurar os exemplos? " +
        "As alterações feitas neste dashboard serão perdidas."
    );

    if (!confirmed) return;

    data = createDemoData();
    saveData(data);
    renderDashboard();
});

/* ========================================
   12. MENU PARA CELULAR
======================================== */

const sidebar = $("sidebar");
const menuButton = $("menuButton");
const overlay = $("mobileOverlay");

function closeMenu() {
    sidebar.classList.remove("open");
    overlay.classList.remove("visible");
    menuButton.setAttribute("aria-expanded", "false");
}

menuButton.addEventListener("click", function () {
    const isOpen = sidebar.classList.toggle("open");

    overlay.classList.toggle("visible", isOpen);
    menuButton.setAttribute("aria-expanded", String(isOpen));
});

overlay.addEventListener("click", closeMenu);

sidebar.querySelectorAll(".nav-link").forEach(link => {
    link.addEventListener("click", closeMenu);
});

/* ========================================
   13. SAIR DO PAINEL
======================================== */

$("logoutButton").addEventListener("click", function () {
    window.location.href = "login.html";
});

/* ========================================
   14. INICIAR DASHBOARD
======================================== */

renderDashboard();
